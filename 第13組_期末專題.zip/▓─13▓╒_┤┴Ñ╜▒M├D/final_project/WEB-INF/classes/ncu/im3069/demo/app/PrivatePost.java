package ncu.im3069.demo.app;

import org.json.*;


public class PrivatePost {
    private int private_id;
    private int member_id;
    private String member_name;
    private String dog_name;
    private String dog_type;
    private String dog_gender;
    private String dog_size;
    private String dog_appearance;
    private String dog_age;
    private String dog_ligation;
    private String dog_area;
    private String description;
    private String image;
    private String contact_name;
    private String contact_phone;
    private String status;

    private PrivateHelper prh = PrivateHelper.getHelper();

    /** 私立送養貼文刊登詳細資訊*/
    public PrivatePost(String dog_name, String dog_type, String dog_gender,
            String dog_size, String dog_appearance, String dog_age,
            String dog_ligation, String dog_area, String description,
            String image, String contact_name, String contact_phone) {
        this.dog_name = dog_name;
        this.dog_type = dog_type;
        this.dog_gender = dog_gender;
        this.dog_size = dog_size;
        this.dog_appearance = dog_appearance;
        this.dog_age = dog_age;
        this.dog_ligation = dog_ligation;
        this.dog_area = dog_area;
        this.description = description;
        this.image = image;
        this.contact_name = contact_name;
        this.contact_phone = contact_phone;
        update();
    }
    
    /** 會員資訊管理私立送養貼文刊登詳細資訊*/
    public PrivatePost(int private_id, int member_id, String dog_name, 
    		String dog_type, String dog_gender,
            String dog_size, String dog_appearance, String dog_age,
            String dog_ligation, String dog_area, String description,
            String image, String contact_name, String contact_phone,String status) {
        this.private_id = private_id;
        this.member_id = member_id;
        this.dog_name = dog_name;
        this.dog_type = dog_type;
        this.dog_gender = dog_gender;
        this.dog_size = dog_size;
        this.dog_appearance = dog_appearance;
        this.dog_age = dog_age;
        this.dog_ligation = dog_ligation;
        this.dog_area = dog_area;
        this.description = description;
        this.image = image;
        this.contact_name = contact_name;
        this.contact_phone = contact_phone;
        this.status=status;
//        getPublicFromDB();  /** 這啥 */
    }
    
    /** 管理員可看的貼文詳細資訊*/
    public PrivatePost(int private_id, int member_id, String member_name,  String dog_name, 
    		String dog_type, String dog_gender,
            String dog_size, String dog_appearance, String dog_age,
            String dog_ligation, String dog_area, String description,
            String image, String contact_name, String contact_phone,String status) {
        this.private_id = private_id;
        this.member_id = member_id;
        this.member_name = member_name;
        this.dog_name = dog_name;
        this.dog_type = dog_type;
        this.dog_gender = dog_gender;
        this.dog_size = dog_size;
        this.dog_appearance = dog_appearance;
        this.dog_age = dog_age;
        this.dog_ligation = dog_ligation;
        this.dog_area = dog_area;
        this.description = description;
        this.image = image;
        this.contact_name = contact_name;
        this.contact_phone = contact_phone;
        this.status=status;
//        getPublicFromDB();  /** 這啥 */
    }
    
    /** 私立送養貼文簡易顯示的資訊*/
    public PrivatePost(int private_id, String dog_name, String dog_type, String dog_gender,String image) {
    	this.private_id = private_id;  
    	this.dog_name = dog_name;
    	this.dog_type = dog_type;
    	this.dog_gender = dog_gender;
    	this.image = image;
    }
    
    public PrivatePost(int private_id, String status) {
    	this.private_id = private_id;  
    	this.status = status;
    }

    public void setId(int id) {
        this.private_id = id;
    }

    public int getID() {
        return this.private_id;
    }

    public int getMemberID() {
        return this.member_id;
    }
    
    public String getMemberName() {
        return this.member_name;
    }
    
    public String getDogName() {
        return this.dog_name;
    }

    public String getDogType() {
        return this.dog_type;
    }

    public String getDogGender() {
        return this.dog_gender;
    }

    public String getDogSize() {
        return this.dog_size;
    }

    public String getDogAppearance() {
        return this.dog_appearance;
    }

    public String getDogAge() {
        return this.dog_age;
    }

    public String getDogLigation() {
        return this.dog_ligation;
    }

    public String getDogArea() {
        return this.dog_area;
    }

    public String getDescription() {
        return this.description;
    }

    public String getImage() {
        return this.image;
    }

    public String getContactName() {
        return this.contact_name;
    }

    public String getContactPhone() {
        return this.contact_phone;
    }
    
    public String getStatus() {
        return this.status;
    }

    public JSONObject update() {
        JSONObject data = new JSONObject();
        if (this.private_id != 0) {
            data = prh.update(this);
        }
        return data;
    }
    
    /** 僅拿大略資料*/
    public JSONObject getData() {
        JSONObject jso = new JSONObject();
        jso.put("private_id", getID());
        jso.put("dog_name", getDogName());
        jso.put("dog_type", getDogType());
        jso.put("dog_gender", getDogGender());
        jso.put("image",getImage());
        return jso;
    }
        
    public JSONObject getPrivateData() {
        JSONObject jso = new JSONObject();
        jso.put("private_id", getID());
        jso.put("member_id", getMemberID());
        jso.put("dog_name", getDogName());
        jso.put("dog_type", getDogType());
        jso.put("dog_gender", getDogGender());
        jso.put("dog_size", getDogSize());
        jso.put("dog_appearance", getDogAppearance());
        jso.put("dog_age", getDogAge());
        jso.put("dog_ligation", getDogLigation());
        jso.put("dog_area", getDogArea());
        jso.put("description", getDescription());
        jso.put("image", getImage());
        jso.put("contact_name", getContactName());
        jso.put("contact_phone", getContactPhone());
        jso.put("status",getStatus());
        return jso;
    }

   
}
