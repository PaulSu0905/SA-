package ncu.im3069.demo.app;

import org.json.*;
import java.util.Calendar;

// TODO: Auto-generated Javadoc
/**
 * <p>
 * The Class Admin
 * Admin類別（class）具有管理員所需要之屬性與方法，並且儲存與管理員相關之商業判斷邏輯<br>
 * </p>
 * 
 * @author IPLab
 * @version 1.0.0
 * @since 1.0.0
 */

public class Admin {
    
    /** id，管理員編號 */
    private int id;
    
    /** name，管理員姓名 */
    private String name;

    /** phone，管理員電話 */
    private String phone;  

    /** password，管理員密碼 */
    private String password;
    
    /** ah，AdminHelper之物件與Admin相關之資料庫方法（Sigleton） */
    private AdminHelper ah =  AdminHelper.getHelper();
    
    /**
     * 實例化（Instantiates）一個新的（new）Admin物件<br>
     * 採用多載（overload）方法進行，此建構子用於建立管理員資料時，產生一名新的管理員
     * 
     * @param name 姓名
     * @param phone
     * @param password 密碼
    
     */
    public Admin(String name, String phone, String password ) {
        this.name = name;
        this.phone = phone;
        this.password = password;
        
        update();
    }

    /**
     * 實例化（Instantiates）一個新的（new）Admin物件<br>
     * 採用多載（overload）方法進行，此建構子用於更新管理員資料時，產生一名管理員
     * 
     * @param id 管理員編號
     * @param name 姓名
     * @param password 密碼
     */
    public Admin(int id, String password, String name) {
        this.id = id;
        this.name = name;
        this.password = password;
        
    }
    
    /**
     * 實例化（Instantiates）一個新的（new）Admin物件<br>
     * 採用多載（overload）方法進行，此建構子用於查詢管理員資料時，將每一筆資料新增為一個管理員物件
     *
     * @param id 編號
     * @param name 姓名
     * @param phone
     * @param password 密碼
     */
    public Admin(int id,String name, String phone, String password) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.password = password;

    }
    
    public Admin(String phone, String password) {
        
        this.phone = phone;
        this.password = password;

    }
    
    /**
     * 取得管理員之編號
     *
     * @return the id 回傳管理員編號
     */
    public int getID() {
        return this.id;
    }

    /**
     * 取得管理員之姓名
     *
     * @return the name 回傳管理員姓名
     */
    public String getName() {
        return this.name;
    }

    /**
     * 取得管理員之電話
     *
     * @return the phone 回傳管理員電話
     */
     public String getPhone() {
        return this.phone;
    }

    /**
     * 取得會員之密碼
     *
     * @return the password 回傳管理員密碼
     */
    public String getPassword() {
        return this.password;
    }

    
    /**
     * 更新管理員資料   (未完成)
     *
     * @return the JSON object 回傳SQL更新之結果與相關封裝之資料
     */
    public JSONObject update() {
        /** 新建一個JSONObject用以儲存更新後之資料 */
        JSONObject data = new JSONObject();
        
        /** 檢查該名管理員是否已經在資料庫 */
        if(this.id != 0) {
            /** 若有則將目前更新後之資料更新至資料庫中 */
            /** 透過AdminHelper物件，更新目前之管理員資料置資料庫中 */
            data = ah.update(this);
        }
        
        return data;
    }
    
    /**
     * 取得該名管理員所有資料
     *
     * @return the data 取得該名管理員之所有資料並封裝於JSONObject物件內
     */
    public JSONObject getData() {
        /** 透過JSONObject將該名會員所需之資料全部進行封裝*/ 
        JSONObject jso = new JSONObject();
        jso.put("id", getID());
        jso.put("name", getName()); 
        jso.put("phone", getPhone());   
        jso.put("password", getPassword()); 
        

        return jso;
    }

    
}