package ncu.im3069.demo.app;

import java.sql.*;

import java.util.ArrayList;
import java.util.List;

import org.json.*;

import ncu.im3069.demo.util.DBMgr;

public class SeekingHelper {

    private SeekingHelper() {

    }

    private static SeekingHelper sh;

    private Connection conn = null;

    private PreparedStatement pres = null;

    public static SeekingHelper getHelper() {
        if (sh == null)
            sh = new SeekingHelper();

        return sh;
    }
    public JSONObject update(Seeking seeking) {
        String executeSql = "";
        long startTime = System.nanoTime();
        int row = 0;

        try {
            conn = DBMgr.getConnection();
            String sql = "UPDATE `db_sa`.`tb_seeking` SET `member_id`=?, `member_name`=?, `dog_name`=?, `dog_type`=?, `dog_gender`=?,"
                    + " `dog_size`=?, `dog_time`=?, `dog_area`=?, `contact_name`=?, `contact_phone`=?, `description`=?, `status`=?, `image`=?"
                    + " WHERE `seeking_id`=?";

            pres = conn.prepareStatement(sql);
            pres.setInt(1, seeking.getMember_id());
            pres.setString(2, seeking.getMember_name());
            pres.setString(3, seeking.getDog_name());
            pres.setString(4, seeking.getDog_type());
            pres.setString(5, seeking.getDog_gender());
            pres.setString(6, seeking.getDog_size());
            pres.setString(7, seeking.getDog_time());
            pres.setString(8, seeking.getDog_area());
            pres.setString(9, seeking.getContact_name());
            pres.setString(10, seeking.getContact_phone());
            pres.setString(11, seeking.getDescription());
            pres.setString(12, seeking.getStatus());
            pres.setString(13, seeking.getImage());
            pres.setInt(14, seeking.getSeeking_id());

            row = pres.executeUpdate();

            executeSql = pres.toString();
            System.out.println(executeSql);

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBMgr.close(pres, conn);
        }

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);

        JSONObject response = new JSONObject();
        response.put("sql", executeSql);
        response.put("time", duration);
        response.put("row", row);

        return response;
    }

    
    
    
    public JSONObject deleteByID(int id) {
        String executeSql = "";
        long startTime = System.nanoTime();
        int row = 0;
        ResultSet rs = null;
        boolean isDeleted = false;
        try {
            conn = DBMgr.getConnection();
            String sql = "DELETE FROM `db_sa`.`tb_seeking` WHERE `seeking_id` = ? LIMIT 1";

            pres = conn.prepareStatement(sql);
            pres.setInt(1, id);
            row = pres.executeUpdate();
            isDeleted = true;
         

            executeSql = pres.toString();
            System.out.println(executeSql);

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBMgr.close(rs, pres, conn);
        }

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);

        JSONObject response = new JSONObject();
        response.put("sql", executeSql);
        response.put("row", row);
        response.put("time", duration);
        response.put("deleted", isDeleted);
        

        return response;
    }

    public JSONObject getAll() {
        Seeking seeking = null;
        JSONArray jsa = new JSONArray();
        String executeSql = "";
        long startTime = System.nanoTime();
        int row = 0;
        ResultSet rs = null;

        try {
            conn = DBMgr.getConnection();
            String sql = "SELECT * FROM `db_sa`.`tb_seeking`";

            pres = conn.prepareStatement(sql);
            rs = pres.executeQuery();

            executeSql = pres.toString();
            System.out.println(executeSql);

            while (rs.next()) {
                row += 1;
                int seeking_id = rs.getInt("seeking_id");
                int member_id = rs.getInt("member_id");
                String member_name = rs.getString("member_name");
                String dog_name = rs.getString("dog_name");
                String dog_type = rs.getString("dog_type");
                String dog_gender = rs.getString("dog_gender");
                String dog_size = rs.getString("dog_size");
                String dog_time = rs.getString("dog_time");
                String dog_area = rs.getString("dog_area");
                String contact_name = rs.getString("contact_name");
                String contact_phone = rs.getString("contact_phone");
                String description = rs.getString("description");
                String status = rs.getString("status");
                String image = rs.getString("image");

                seeking = new Seeking(seeking_id, member_id, member_name, dog_name, dog_type, dog_gender, dog_size,
                        dog_time, dog_area, contact_name, contact_phone, description, status, image);
                jsa.put(seeking.toJSON());
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBMgr.close(rs, pres, conn);
        }

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);

        JSONObject response = new JSONObject();
        response.put("sql", executeSql);
        response.put("row", row);
        response.put("time", duration);
        response.put("data", jsa);

        return response;
    }

    public JSONObject getByID(String seeking_id) {
        Seeking seeking = null;
        JSONArray jsa = new JSONArray();
        String executeSql = "";
        long startTime = System.nanoTime();
        int row = 0;
        ResultSet rs = null;

        try {
            conn = DBMgr.getConnection();
            String sql = "SELECT * FROM `db_sa`.`tb_seeking` WHERE `seeking_id` = ? LIMIT 1";

            pres = conn.prepareStatement(sql);
            pres.setString(1, seeking_id);
            rs = pres.executeQuery();

            executeSql = pres.toString();
            System.out.println(executeSql);

            if (rs.next()) {
                String dog_name = rs.getString("dog_name");
                String dog_type = rs.getString("dog_type");
                String dog_gender = rs.getString("dog_gender");
                String dog_size = rs.getString("dog_size");
                String dog_time = rs.getString("dog_time");
                String dog_area = rs.getString("dog_area");
                String contact_name = rs.getString("contact_name");
                String contact_phone = rs.getString("contact_phone");
                String description = rs.getString("description");
                String status = rs.getString("status");
                String image = rs.getString("image");

                Seeking sk = new Seeking(dog_name, dog_type, dog_gender, dog_size,
                dog_time, dog_area, contact_name, contact_phone, description, status, image);
                jsa.put(sk.toJSON());
            }
        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBMgr.close(rs, pres, conn);
        }

        
        
        long endTime = System.nanoTime();
        long duration = (endTime - startTime);

        JSONObject response = new JSONObject();
        response.put("sql", executeSql);
        response.put("row", row);
        response.put("time", duration);
        response.put("data", jsa);

        return response;
    }

    public JSONObject getByMember(String member_id) {
        Seeking sk = null;
        /** 用於儲存所有檢索回之協尋貼文，以JSONArray方式儲存 */
        JSONArray jsa = new JSONArray();
        /** 記錄實際執行之SQL指令 */
        String exexcute_sql = "";
        /** 紀錄程式開始執行時間 */
        long start_time = System.nanoTime();
        /** 紀錄SQL總行數 */
        int row = 0;
        /** 儲存JDBC檢索資料庫後回傳之結果，以 pointer 方式移動到下一筆資料 */
        ResultSet rs = null;
        
        try {
            /** 取得資料庫之連線 */
            conn = DBMgr.getConnection();
            /** SQL指令 */
            String sql = "SELECT * FROM `db_sa`.`tb_seeking` WHERE member_id = ?";
            
            /** 將參數回填至SQL指令當中 */
            pres = conn.prepareStatement(sql);

            pres.setInt(1, Integer.parseInt(member_id));
            /** 執行查詢之SQL指令並記錄其回傳之資料 */
            rs = pres.executeQuery();

            /** 紀錄真實執行的SQL指令，並印出 **/
            exexcute_sql = pres.toString();
            System.out.println(exexcute_sql);
            
            while (rs.next()) {
             row++;
                /** 將 ResultSet 之資料取出 */
             int m_id = rs.getInt("member_id");
             int p_id = rs.getInt("seeking_id");
                String name = rs.getString("dog_name");
                String type = rs.getString("dog_type");
                String gender = rs.getString("dog_gender");
                String size = rs.getString("dog_size");
                String time = rs.getString("dog_time");
                String area = rs.getString("dog_area");
                String description = rs.getString("description");
                String image = rs.getString("image");
                String contact_name = rs.getString("contact_name");
                String contact_phone = rs.getString("contact_phone");
                String status = rs.getString("status");

                /** 將該筆協尋貼文資料產生一名新 Seeking 物件 */
                sk = new Seeking(p_id, m_id, name, type, gender, size, time, area, contact_name, contact_phone, description, status, image);
                /** 將該協尋貼文之資料封裝至 JSONArray 內 */
                jsa.put(sk.toJSON());
            }
            
            
        } catch (SQLException e) {
            /** 印出JDBC SQL指令錯誤 **/
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            /** 若錯誤則印出錯誤訊息 */
            e.printStackTrace();
        } finally {
            /** 關閉連線並釋放所有資料庫相關之資源 **/
            DBMgr.close(rs, pres, conn);
        }
        
        /** 紀錄程式結束執行時間 */
        long end_time = System.nanoTime();
        /** 紀錄程式執行時間 */
        long duration = (end_time - start_time);
        
        /** 將SQL指令、花費時間、影響行數與所有協尋貼文資料之JSONArray，封裝成JSONObject回傳 */
        JSONObject response = new JSONObject();
        response.put("sql", exexcute_sql);
        response.put("row", row);
        response.put("time", duration);
        response.put("data", jsa);

        return response;
    }
    
    
    public JSONObject create(Seeking seeking) {
        String executeSql = "";
        long startTime = System.nanoTime();
        int row = 0;

        try {
            conn = DBMgr.getConnection();
            String sql = "INSERT INTO `db_sa`.`tb_seeking`(`member_id`, `member_name`, `dog_name`, `dog_type`, `dog_gender`,"
                    + " `dog_size`, `dog_time`, `dog_area`, `contact_name`, `contact_phone`, `description`, `status`, `image`)"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            pres = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pres.setInt(1, seeking.getMember_id());
            pres.setString(2, seeking.getMember_name());
            pres.setString(3, seeking.getDog_name());
            pres.setString(4, seeking.getDog_type());
            pres.setString(5, seeking.getDog_gender());
            pres.setString(6, seeking.getDog_size());
            pres.setString(7, seeking.getDog_time());
            pres.setString(8, seeking.getDog_area());
            pres.setString(9, seeking.getContact_name());
            pres.setString(10, seeking.getContact_phone());
            pres.setString(11, seeking.getDescription());
            pres.setString(12, seeking.getStatus());
            pres.setString(13, seeking.getImage());

            row = pres.executeUpdate();

            ResultSet generatedKeys = pres.getGeneratedKeys();
            if (generatedKeys.next()) {
                seeking.setSeeking_id(generatedKeys.getInt(1));
            }

            executeSql = pres.toString();
            System.out.println(executeSql);

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBMgr.close(pres, conn);
        }

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);

        JSONObject response = new JSONObject();
        response.put("sql", executeSql);
        response.put("time", duration);
        response.put("row", row);

        return response;
    }


public boolean isSeekingRecordExists(Seeking seekingPost) {
        int recordCount = 0;
        ResultSet rs = null;

        try {
            conn = DBMgr.getConnection();
            String sql = "SELECT COUNT(*) AS recordCount FROM `db_sa`.`tb_seeking` WHERE " +
                         "`dog_name` = ? AND " +
                         "`dog_type` = ? AND " +
                         "`dog_gender` = ? AND " +
                         "`dog_size` = ? AND " +
                         "`dog_time` = ? AND " +
                         "`dog_area` = ?";
            
            pres = conn.prepareStatement(sql);
            pres.setString(1, seekingPost.getDog_name());
            pres.setString(2, seekingPost.getDog_type());
            pres.setString(3, seekingPost.getDog_gender());
            pres.setString(4, seekingPost.getDog_size());
            pres.setString(5, seekingPost.getDog_time());
            pres.setString(6, seekingPost.getDog_area());

            rs = pres.executeQuery();
            
            rs.next();
            recordCount = rs.getInt("recordCount");

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBMgr.close(rs, pres, conn);
        }

        return (recordCount > 0);
    }

    public JSONObject getByConditions(String dogType, String dogArea) {
        Seeking seeking = null;
        JSONArray jsa = new JSONArray();
        String executeSql = "";
        long startTime = System.nanoTime();
        int row = 0;
        ResultSet rs = null;

        try {
            conn = DBMgr.getConnection();
            StringBuilder sqlBuilder = new StringBuilder("SELECT * FROM `db_sa`.`tb_seeking` WHERE 1=1");

            List<String> conditions = new ArrayList<>();
            if (dogType != null && !dogType.isEmpty()) {
                conditions.add("`dog_type` = ?");
            }
            if (dogArea != null && !dogArea.isEmpty()) {
                conditions.add("`dog_area` = ?");
            }

            if (!conditions.isEmpty()) {
                sqlBuilder.append(" AND (").append(String.join(" OR ", conditions)).append(")");
            }

            pres = conn.prepareStatement(sqlBuilder.toString());

            int parameterIndex = 1;
            if (dogType != null && !dogType.isEmpty()) {
                pres.setString(parameterIndex++, dogType);
            }
            if (dogArea != null && !dogArea.isEmpty()) {
                pres.setString(parameterIndex++, dogArea);
            }

            rs = pres.executeQuery();

            executeSql = pres.toString();
            System.out.println(executeSql);

            while (rs.next()) {
                row += 1;
                int seeking_id = rs.getInt("seeking_id");
                int member_id = rs.getInt("member_id");
                String member_name = rs.getString("member_name");
                String dog_name = rs.getString("dog_name");
                String type = rs.getString("dog_type");
                String gender = rs.getString("dog_gender");
                String size = rs.getString("dog_size");
                String time = rs.getString("dog_time");
                String area = rs.getString("dog_area");
                String contact_name = rs.getString("contact_name");
                String contact_phone = rs.getString("contact_phone");
                String description = rs.getString("description");
                String status = rs.getString("status");
                String image = rs.getString("image");

                seeking = new Seeking(seeking_id, member_id, member_name, dog_name, type, gender, size, time, area,
                        contact_name, contact_phone, description, status, image);
                jsa.put(seeking.toJSON());
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBMgr.close(rs, pres, conn);
        }

        long endTime = System.nanoTime();
        long duration = (endTime - startTime);

        JSONObject response = new JSONObject();
        response.put("sql", executeSql);
        response.put("row", row);
        response.put("time", duration);
        response.put("data", jsa);

        return response;
    }

    public JSONObject updateStatus(Seeking sk) {
        /** 紀錄回傳之資料 */
        JSONArray jsa = new JSONArray();
        /** 記錄實際執行之SQL指令 */
        String exexcute_sql = "";
        /** 紀錄程式開始執行時間 */
        long start_time = System.nanoTime();
        /** 紀錄SQL總行數 */
        int row = 0;
        
        try {
            /** 取得資料庫之連線 */
            conn = DBMgr.getConnection();
            /** SQL指令 */
            String sql = "Update `db_sa`.`tb_seeking` SET `status` = ?  WHERE `seeking_id` = ?";
            /** 取得所需之參數 */
            int id = sk.getSeeking_id();
            String status = sk.getStatus();
            
            /** 將參數回填至SQL指令當中 */
            pres = conn.prepareStatement(sql);
            pres.setString(1, status);
            pres.setInt(2, id);
            /** 執行更新之SQL指令並記錄影響之行數 */
            row = pres.executeUpdate();

            /** 紀錄真實執行的SQL指令，並印出 **/
            exexcute_sql = pres.toString();
            System.out.println(exexcute_sql);

        } catch (SQLException e) {
            /** 印出JDBC SQL指令錯誤 **/
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            /** 若錯誤則印出錯誤訊息 */
            e.printStackTrace();
        } finally {
            /** 關閉連線並釋放所有資料庫相關之資源 **/
            DBMgr.close(pres, conn);
        }
        
        /** 紀錄程式結束執行時間 */
        long end_time = System.nanoTime();
        /** 紀錄程式執行時間 */
        long duration = (end_time - start_time);
        
        /** 將SQL指令、花費時間與影響行數，封裝成JSONObject回傳 */
        JSONObject response = new JSONObject();
        response.put("sql", exexcute_sql);
        response.put("row", row);
        response.put("time", duration);
        response.put("data", jsa);

        return response;
    }
}
