package ncu.im3069.demo.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import ncu.im3069.demo.app.PublicHelper;
import ncu.im3069.demo.app.PublicPost;
import ncu.im3069.tools.JsonReader;

@WebServlet("/api/PublicPost.do")
public class PublicPostController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/** puh，PublicHelper 之物件與 PublicPost 相關之資料庫方法（Sigleton） */
    private PublicHelper puh = PublicHelper.getHelper();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PublicPostController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/** 透過 JsonReader 類別將 Request 之 JSON 格式資料解析並取回 */
        JsonReader jsr = new JsonReader(request);

        /** 取出經解析到 JsonReader 之 Request 參數 */
        String id = jsr.getParameter("public_id");

        /** 新建一個 JSONObject 用於將回傳之資料進行封裝 */
        JSONObject resp = new JSONObject();

        /** 判斷該字串是否存在，若存在代表要取回個別貼文之資料，否則代表要取回全部資料庫內貼文之資料 */
        if (!id.isEmpty()) {
            /** 透過 PublicPostHelper 物件的 getByID() 方法自資料庫取回該筆訂單之資料，回傳之資料為 JSONObject 物件 */
            JSONObject query = puh.getByID(id);
            resp.put("status", "200");
            resp.put("message", "貼文資料取得成功");
            resp.put("response", query);
        } else {
            /** 透過 PublicPostHelper 物件之 getAll() 方法取回所有訂單之資料，回傳之資料為 JSONObject 物件 */
            JSONObject query = puh.getAll();
            resp.put("status", "200");
            resp.put("message", "所有貼文資料取得成功");
            resp.put("response", query);
        }
        /** 透過 JsonReader 物件回傳到前端（以 JSONObject 方式） */
        jsr.response(resp, response);
	}

	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JsonReader jsr = new JsonReader(request);
        JSONObject jso = jsr.getObject();
        // Retrieve the operation parameter
        String operation = jso.getString("operation");

        if ("submitPublicDoPost".equals(operation)) {
            int admin_id = jso.getInt("admin_id");
            String admin_name = jso.getString("admin_name");
            String dog_name = jso.getString("dog_name");
            String dog_type = jso.getString("dog_type");
            String dog_gender = jso.getString("dog_gender");
            String dog_size = jso.getString("dog_size");
            String dog_appearance = jso.getString("dog_appearance");
            String dog_age = jso.getString("dog_age");
            String dog_ligation = jso.getString("dog_ligation");
            String dog_area = jso.getString("dog_area");
            String description = jso.getString("description");
            String image = jso.getString("image");
            String contact_name = jso.getString("contact_name");
            String contact_phone = jso.getString("contact_phone");

            PublicPost publicpost = new PublicPost(0, admin_id, admin_name, dog_name, dog_type, dog_gender, dog_size,
                    dog_appearance, dog_age, dog_ligation, dog_area, description, image, contact_name, contact_phone);

            boolean isPublicRecordExists = puh.isPublicRecordExists(publicpost);
            if (isPublicRecordExists) {
                JSONObject resp = new JSONObject();
                resp.put("status", "400");
                resp.put("message", "相似的公立貼文已存在");
                jsr.response(resp, response);
                return;
            }

            JSONObject result = puh.create(publicpost);

            JSONObject resp = new JSONObject();
            resp.put("status", "200");
            resp.put("message", "公立貼文新增成功！");
            resp.put("data", result);

            jsr.response(resp, response);
        } else {
            String resp = "{\"status\": '400', \"message\": '未知操作', \"response\": ''}";
            jsr.response(resp, response);
        }
    }

	/**
	 * @see HttpServlet#doDelete(HttpServletRequest, HttpServletResponse)
	 */
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		JsonReader jsr = new JsonReader(request);
        JSONObject jso = jsr.getObject();

        int public_id = jso.getInt("public_id"); 

        JSONObject resp = new JSONObject();

        JSONObject deletionResult = puh.deleteByID(public_id);

        if (deletionResult.has("deleted") && deletionResult.getBoolean("deleted")) {
            resp.put("status", "200");
            resp.put("message", "貼文移除成功！");
            resp.put("response", deletionResult);
        } else {
            resp.put("status", "400");
            resp.put("message", "貼文移除失敗！");
            resp.put("response", deletionResult);
        }

        jsr.response(resp, response);
	}

}
