package ncu.im3069.demo.app;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.json.*;

import ncu.im3069.demo.app.Member;
import ncu.im3069.demo.app.PublicPost;
import ncu.im3069.demo.util.DBMgr;

// TODO: Auto-generated Javadoc
/**
 * <p>
 * The Class PublicHelper<br>
 * PublicHelper類別（class）主要管理所有與Public相關與資料庫之方法（method）
 * </p>
 * 
 * @author IPLab
 * @version 1.0.0
 * @since 1.0.0
 */

public class PublicHelper {
    
    /**
     * 實例化（Instantiates）一個新的（new）PublicHelper物件<br>
     * 採用Singleton不需要透過new
     */
    private PublicHelper() {
        
    }
    
    /** 靜態變數，儲存PublicHelper物件 */
    private static PublicHelper puh;
    
    /** 儲存JDBC資料庫連線 */
    private Connection conn = null;
    
    /** 儲存JDBC預準備之SQL指令 */
    private PreparedStatement pres = null;
    
    /**
     * 靜態方法<br>
     * 實作Singleton（單例模式），僅允許建立一個PublicHelper物件
     *
     * @return the helper 回傳PublicHelper物件
     */
    public static PublicHelper getHelper() {
        /** Singleton檢查是否已經有PublicHelper物件，若無則new一個，若有則直接回傳 */
        if( puh == null) puh = new PublicHelper();
        
        return puh;
    }
    
    /**
     * 透過公立送養貼文編號（ID）刪除公立送養貼文
     *
     * @param id 公立送養貼文編號
     * @return the JSONObject 回傳SQL執行結果
     */
    public JSONObject deleteByID(int id) {
        /** 記錄實際執行之SQL指令 */
        String exexcute_sql = "";
        /** 紀錄程式開始執行時間 */
        long start_time = System.nanoTime();
        /** 紀錄SQL總行數 */
        int row = 0;
        /** 儲存JDBC檢索資料庫後回傳之結果，以 pointer 方式移動到下一筆資料 */
        ResultSet rs = null;
        boolean isDeleted = false;
        
        try {
            /** 取得資料庫之連線 */
            conn = DBMgr.getConnection();
            
            /** SQL指令 */
            String sql = "DELETE FROM `db_sa`.`tb_public` WHERE `public_id` = ? LIMIT 1";
            
            /** 將參數回填至SQL指令當中 */
            pres = conn.prepareStatement(sql);
            pres.setInt(1, id);
            /** 執行刪除之SQL指令並記錄影響之行數 */
            row = pres.executeUpdate();
            isDeleted = true;
            /** 紀錄真實執行的SQL指令，並印出 **/
            exexcute_sql = pres.toString();
            System.out.println(exexcute_sql);
            
        } catch (SQLException e) {
            /** 印出JDBC SQL指令錯誤 **/
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            /** 若錯誤則印出錯誤訊息 */
            e.printStackTrace();
        } finally {
            /** 關閉連線並釋放所有資料庫相關之資源 **/
            DBMgr.close(rs, pres, conn);
        }

        /** 紀錄程式結束執行時間 */
        long end_time = System.nanoTime();
        /** 紀錄程式執行時間 */
        long duration = (end_time - start_time);
        
        /** 將SQL指令、花費時間與影響行數，封裝成JSONObject回傳 */
        JSONObject response = new JSONObject();
        response.put("sql", exexcute_sql);
        response.put("row", row);
        response.put("time", duration);
        response.put("deleted", isDeleted);
        return response;
    }
    
    /**
     * 取回所有公立送養貼文資料
     *
     * @return the JSONObject 回傳SQL執行結果與自資料庫取回之所有資料
     */
    public JSONObject getAll() {
        /** 新建一個 Public 物件之 pc 變數，用於紀錄每一位查詢回之公立送養貼文資料 */
        PublicPost pc = null;
        /** 用於儲存所有檢索回之公立送養貼文，以JSONArray方式儲存 */
        JSONArray jsa = new JSONArray();
        /** 記錄實際執行之SQL指令 */
        String exexcute_sql = "";
        /** 紀錄程式開始執行時間 */
        long start_time = System.nanoTime();
        /** 紀錄SQL總行數 */
        int row = 0;
        /** 儲存JDBC檢索資料庫後回傳之結果，以 pointer 方式移動到下一筆資料 */
        ResultSet rs = null;
        
        try {
            /** 取得資料庫之連線 */
            conn = DBMgr.getConnection();
            /** SQL指令 */
            String sql = "SELECT * FROM `db_sa`.`tb_public`";
            
            /** 將參數回填至SQL指令當中，若無則不用只需要執行 prepareStatement */
            pres = conn.prepareStatement(sql);
            /** 執行查詢之SQL指令並記錄其回傳之資料 */
            rs = pres.executeQuery();

            /** 紀錄真實執行的SQL指令，並印出 **/
            exexcute_sql = pres.toString();
            System.out.println(exexcute_sql);
            
            /** 透過 while 迴圈移動pointer，取得每一筆回傳資料 */
            while(rs.next()) {
                /** 每執行一次迴圈表示有一筆資料 */
                row += 1;
                /** 將 ResultSet 之資料取出 */
                int public_id = rs.getInt("public_id");
                int admin_id = rs.getInt("admin_id");
                String admin_name=rs.getString("admin_name");
                String dog_name = rs.getString("dog_name");
                String dog_type = rs.getString("dog_type");
                String dog_gender = rs.getString("dog_gender");
                String dog_size=rs.getString("dog_size");
                String dog_appearance = rs.getString("dog_appearance");
                String contact_name = rs.getString("contact_name");
                String dog_age = rs.getString("dog_age");
                String dog_ligation = rs.getString("dog_ligation");
                String dog_area  = rs.getString("dog_area");
                String contact_phone = rs.getString("contact_phone");
                String description = rs.getString("description");
                String image = rs.getString("image");
                
                	
                /** 將每一筆公立送養貼文資料產生一名新Public物件 */
                pc = new PublicPost(public_id,admin_id,admin_name, dog_name, dog_type, dog_gender,dog_size,dog_appearance,dog_age,dog_ligation,dog_area,description,image,contact_name,contact_phone);
                /** 取出該名公立送養貼文之資料並封裝至 JSONsonArray 內 */
                jsa.put(pc.getPublicData());
            }

        } catch (SQLException e) {
            /** 印出JDBC SQL指令錯誤 **/
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) { 
            /** 若錯誤則印出錯誤訊息 */
            e.printStackTrace();
        } finally {
            /** 關閉連線並釋放所有資料庫相關之資源 **/
            DBMgr.close(rs, pres, conn);
        }
        
        /** 紀錄程式結束執行時間 */
        long end_time = System.nanoTime();
        /** 紀錄程式執行時間 */
        long duration = (end_time - start_time);
        
        /** 將SQL指令、花費時間、影響行數與所有公立送養貼文資料之JSONArray，封裝成JSONObject回傳 */
        JSONObject response = new JSONObject();
        response.put("sql", exexcute_sql);
        response.put("row", row);
        response.put("time", duration);
        response.put("data", jsa);

        return response;
    }
    
    /**
     * 透過公立送養貼文編號（ID）取得公立送養貼文資料
     *
     * @param id 公立送養貼文編號
     * @return the JSON object 回傳SQL執行結果與該公立送養貼文編號之公立送養貼文資料
     */
    public JSONObject getByID(String id) {
        /** 新建一個 Public 物件之 pc 變數，用於紀錄每一位查詢回之公立送養貼文資料 */
        PublicPost pc = null;
        /** 用於儲存所有檢索回之公立送養貼文，以JSONArray方式儲存 */
        JSONArray jsa = new JSONArray();
        /** 記錄實際執行之SQL指令 */
        String exexcute_sql = "";
        /** 紀錄程式開始執行時間 */
        long start_time = System.nanoTime();
        /** 紀錄SQL總行數 */
        int row = 0;
        /** 儲存JDBC檢索資料庫後回傳之結果，以 pointer 方式移動到下一筆資料 */
        ResultSet rs = null;
        
        try {
            /** 取得資料庫之連線 */
            conn = DBMgr.getConnection();
            /** SQL指令 */
            String sql = "SELECT * FROM `db_sa`.`tb_public` WHERE `public_id` = ? LIMIT 1";
            
            /** 將參數回填至SQL指令當中 */
            pres = conn.prepareStatement(sql);
            pres.setString(1, id);
            /** 執行查詢之SQL指令並記錄其回傳之資料 */
            rs = pres.executeQuery();

            /** 紀錄真實執行的SQL指令，並印出 **/
            exexcute_sql = pres.toString();
            System.out.println(exexcute_sql);
            
            if (rs.next()) {
                /** 將 ResultSet 之資料取出 */
                String name = rs.getString("public_name");
                String type = rs.getString("public_type");
                String gender = rs.getString("public_gender");
                String size = rs.getString("public_size");
                String appearance = rs.getString("public_appearance");
                String age = rs.getString("public_age");
                String ligation = rs.getString("public_ligation");
                String area = rs.getString("public_area");
                String description = rs.getString("public_description");
                String  image = rs.getString("public_image");
                String contact_name = rs.getString("public_contact_name");
                String contact_phone = rs.getString("public_contact_phone");

                /** 將該筆公立送養貼文資料產生一名新 Public 物件 */
                pc = new PublicPost(name, type, gender, size, appearance, age, ligation, area, description, image, contact_name, contact_phone);
                /** 將該公立送養貼文之資料封裝至 JSONArray 內 */
                jsa.put(pc.getData());
            }
            
            
        } catch (SQLException e) {
            /** 印出JDBC SQL指令錯誤 **/
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            /** 若錯誤則印出錯誤訊息 */
            e.printStackTrace();
        } finally {
            /** 關閉連線並釋放所有資料庫相關之資源 **/
            DBMgr.close(rs, pres, conn);
        }
        
        /** 紀錄程式結束執行時間 */
        long end_time = System.nanoTime();
        /** 紀錄程式執行時間 */
        long duration = (end_time - start_time);
        
        /** 將SQL指令、花費時間、影響行數與所有公立送養貼文資料之JSONArray，封裝成JSONObject回傳 */
        JSONObject response = new JSONObject();
        response.put("sql", exexcute_sql);
        response.put("row", row);
        response.put("time", duration);
        response.put("data", jsa);

        return response;
    }
    
    
    /**
     * 建立該公立送養貼文至資料庫
     *
     * @param pc 一名公立送養貼文之Public物件
     * @return the JSON object 回傳SQL指令執行之結果
     */
    public JSONObject create(PublicPost publicPost) {
        /** Record the actual executed SQL command */
        String executeSql = "";
        /** Record the program's start execution time */
        long startTime = System.nanoTime();
        /** Record the total number of SQL rows */
        int row = 0;

        try {
            /** Get the database connection */
            conn = DBMgr.getConnection();
            /** SQL command */
            String sql = "INSERT INTO `db_sa`.`tb_public`(`admin_id`, `admin_name`, `dog_name`, `dog_type`, `dog_gender`, `dog_size`, `dog_appearance`, `dog_age`, `dog_ligation`, `dog_area`, `contact_name`, `contact_phone`, `description`, `image`)"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            /** Get the required parameters */
            int adminId = publicPost.getadminid();
            String adminName = publicPost.getadminname();
            String dogName = publicPost.getDogName();
            String dogType = publicPost.getDogType();
            String dogGender = publicPost.getDogGender();
            String dogSize = publicPost.getDogSize();
            String dogAppearance = publicPost.getDogAppearance();
            String dogAge = publicPost.getDogAge();
            String dogLigation = publicPost.getDogLigation();
            String dogArea = publicPost.getDogArea();
            String description = publicPost.getDescription();
            String image = publicPost.getImage();
            String contactName = publicPost.getContactName();
            String contactPhone = publicPost.getContactPhone();

            /** Set the parameters to the SQL command */
            pres = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            pres.setInt(1, adminId);
            pres.setString(2, adminName);
            pres.setString(3, dogName);
            pres.setString(4, dogType);
            pres.setString(5, dogGender);
            pres.setString(6, dogSize);
            pres.setString(7, dogAppearance);
            pres.setString(8, dogAge);
            pres.setString(9, dogLigation);
            pres.setString(10, dogArea);
            pres.setString(11, contactName);
            pres.setString(12, contactPhone);
            pres.setString(13, description);
            pres.setString(14, image);

            /** Execute the SQL command for insertion and record the number of affected rows */
            row = pres.executeUpdate();
            

            ResultSet generatedKeys = pres.getGeneratedKeys();
            if (generatedKeys.next()) {
                publicPost.setId(generatedKeys.getInt(1));
            }
            /** Record the actual executed SQL command and print it **/
            executeSql = pres.toString();
            System.out.println(executeSql);

        } catch (SQLException e) {
            /** Print JDBC SQL command error **/
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            /** If an error occurs, print the error message */
            e.printStackTrace();
        } finally {
            /** Close the connection and release all related database resources **/
            DBMgr.close(pres, conn);
        }

        /** Record the program's end execution time */
        long endTime = System.nanoTime();
        /** Record the program's execution time */
        long duration = (endTime - startTime);

        /** Package the SQL command, execution time, and affected rows into a JSONObject and return it */
        JSONObject response = new JSONObject();
        response.put("sql", executeSql);
        response.put("time", duration);
        response.put("row", row);

        return response;
    }



public boolean isPublicRecordExists(PublicPost publicpost) {
        int row = 0;
        ResultSet rs = null;

        try {
            conn = DBMgr.getConnection();
            String sql = "SELECT COUNT(*) AS row FROM `db_sa`.`tb_public` WHERE " +
                    "`dog_name` = ? AND " +
                    "`dog_type` = ? AND " +
                    "`dog_gender` = ? AND " +
                    "`dog_size` = ? AND " +
                    "`dog_appearance` = ? AND " +
                    "`dog_age` = ? AND " +
                    "`dog_ligation` = ? AND " +
                    "`dog_area` = ?";
            
            pres = conn.prepareStatement(sql);
            pres.setString(1, publicpost.getDogName());
            pres.setString(2, publicpost.getDogType());
            pres.setString(3, publicpost.getDogGender());
            pres.setString(4, publicpost.getDogSize());
            pres.setString(5, publicpost.getDogAppearance());
            pres.setString(6, publicpost.getDogAge());
            pres.setString(7, publicpost.getDogLigation());
            pres.setString(8, publicpost.getDogArea());

            rs = pres.executeQuery();
            
            rs.next();
            row = rs.getInt("row");

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBMgr.close(rs, pres, conn);
        }

        return (row > 0);
    }
    
    /** 條件搜尋*/
    public JSONObject getByConditions(String Type, String Area) {
      /** 新建一個 Public 物件之 pc 變數，用於紀錄每一位查詢回之公立送養貼文 */
      PublicPost pc = null;
      /** 用於儲存所有檢索回之公立送養貼文，以JSONArray方式儲存 */    /** ?  */
      JSONArray jsa = new JSONArray();
      /** 記錄實際執行之SQL指令 */
      String exexcute_sql = "";
      /** 紀錄程式開始執行時間 */
      long start_time = System.nanoTime();
      /** 紀錄SQL總行數 */
      int row = 0;
      /** 儲存JDBC檢索資料庫後回傳之結果，以 pointer 方式移動到下一筆資料 */
      ResultSet rs = null;

      try {
          /** 取得資料庫之連線 */
          conn = DBMgr.getConnection();
          StringBuilder sqlBuilder = new StringBuilder("SELECT * FROM `db_sa`.`tb_public` WHERE 1=1");
          /** SQL指令 */
          List<String> conditions = new ArrayList<>();
        if (Type != null && !Type.isEmpty()) {
            conditions.add("`dog_type` = ?");
        }
        if (Area != null && !Area.isEmpty()) {
            conditions.add("`dog_area` = ?");
        }

        if (!conditions.isEmpty()) {
            sqlBuilder.append(" AND (").append(String.join(" OR ", conditions)).append(")");
        }

        pres = conn.prepareStatement(sqlBuilder.toString());

        // 填入條件值
        int parameterIndex = 1;
        if (Type != null && !Type.isEmpty()) {
            pres.setString(parameterIndex++, Type);
        }
        if (Area != null && !Area.isEmpty()) {
            pres.setString(parameterIndex++, Area);
        }

          /** 執行查詢之SQL指令並記錄其回傳之資料 */
          rs = pres.executeQuery();

          /** 紀錄真實執行的SQL指令，並印出 **/
          exexcute_sql = pres.toString();
          System.out.println(exexcute_sql);
          
          /** 透過 while 迴圈移動pointer，取得每一筆回傳資料 */
          while(rs.next()) {
              /** 每執行一次迴圈表示有一筆資料 */
              row += 1;
              
              /** 將 ResultSet 之資料取出 */
                String name = rs.getString("public_name");
                String type = rs.getString("public_type");
                String gender = rs.getString("public_gender");
                String size = rs.getString("public_size");
                String appearance = rs.getString("public_appearance");
                String age = rs.getString("public_age");
                String ligation = rs.getString("public_ligation");
                String area = rs.getString("public_area");
                String description = rs.getString("public_description");
                String image = rs.getString("public_image");
                String contact_name = rs.getString("public_contact_name");
                String contact_phone = rs.getString("public_contact_phone");
                
              /** 將每一筆貼文資料產生一名新Public物件 */
              pc = new PublicPost(name, type, gender, size, appearance, age, ligation, area, description, image, contact_name, contact_phone);
              /** 取出該項貼文之資料並封裝至 JSONsonArray 內 */
              jsa.put(pc.getData());
          }

      } catch (SQLException e) {
          /** 印出JDBC SQL指令錯誤 **/
          System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
      } catch (Exception e) {
          /** 若錯誤則印出錯誤訊息 */
          e.printStackTrace();
      } finally {
          /** 關閉連線並釋放所有資料庫相關之資源 **/
          DBMgr.close(rs, pres, conn);
      }
      
      /** 紀錄程式結束執行時間 */
      long end_time = System.nanoTime();
      /** 紀錄程式執行時間 */
      long duration = (end_time - start_time);
      
      /** 將SQL指令、花費時間、影響行數與所有公立送養貼文資料之JSONArray，封裝成JSONObject回傳 */
      JSONObject response = new JSONObject();
      response.put("sql", exexcute_sql);
      response.put("row", row);
      response.put("time", duration);
      response.put("data", jsa);

      return response;
    }
    
    
    	
}
            
 
