package ncu.im3069.demo.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import org.json.*;
import ncu.im3069.demo.app.Admin;
import ncu.im3069.demo.app.AdminHelper;
import ncu.im3069.demo.app.Member;
import ncu.im3069.demo.app.MemberHelper;
import ncu.im3069.tools.JsonReader;

// TODO: Auto-generated Javadoc
/**
 * <p>
 * The Class MemberController<br>
 * MemberController類別（class）主要用於處理Member相關之Http請求（Request），繼承HttpServlet
 * </p>
 * 
 * @author IPLab
 * @version 1.0.0
 * @since 1.0.0
 */
@WebServlet("/api/admin.do")
public class AdminController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private AdminHelper ah = AdminHelper.getHelper();
    private AdminHelper mh = AdminHelper.getHelper();

    /**
     * 處理Http Method請求POST方法（新增管理員資料）
     *
     * @param request Servlet請求之HttpServletRequest之Request物件（前端到後端）
     * @param response Servlet回傳之HttpServletResponse之Response物件（後端到前端）
     * @throws ServletException the servlet exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JsonReader jsr = new JsonReader(request);
        JSONObject jso = jsr.getObject();

        String admin_phone = jso.getString("admin_phone");
        String admin_password = jso.getString("admin_password");

        if (admin_phone == null || admin_password == null || admin_phone.isEmpty() || admin_password.isEmpty()) {
	        JSONObject resp = new JSONObject();
	        resp.put("status", "400");
	        resp.put("message", "管理員姓名或密碼不能為空");
	        jsr.response(resp, response);
	        return;
	    }

	    Admin am = ah.getAdminByPhone(admin_phone);

	    if (am == null) {
	        JSONObject resp = new JSONObject();
	        resp.put("status", "401");
	        resp.put("message", "管理員不存在");
	        jsr.response(resp, response);
	        return;
	    }

	    if (!am.getPassword().equals(admin_password)) {
	        JSONObject resp = new JSONObject();
	        resp.put("status", "401");
	        resp.put("message", "密碼錯誤");
	        jsr.response(resp, response);
	        return;
	    }

	    JSONObject resp = new JSONObject();
	    resp.put("status", "200");
	    resp.put("message", "登入成功");
	    resp.put("admin_id", am.getID()); 
	    resp.put("admin_name", am.getName()); 
	    jsr.response(resp, response);
    }
    
    /**
     * 處理Http Method請求GET方法（取得管理員資料）
     *
     * @param request Servlet請求之HttpServletRequest之Request物件（前端到後端）
     * @param response Servlet回傳之HttpServletResponse之Response物件（後端到前端）
     * @throws ServletException the servlet exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JsonReader jsr = new JsonReader(request);
        String id = jsr.getParameter("admin_id");

        if (id == null || id.isEmpty()) {
            JSONObject query = ah.getAll();
            JSONObject resp = new JSONObject();
            resp.put("status", "200");
            resp.put("message", "所有管理員資料取得成功");
            resp.put("response", query);
            jsr.response(resp, response);
        } else {
            JSONObject query = ah.getByID(id);
            JSONObject resp = new JSONObject();
            resp.put("status", "200");
            resp.put("message", "管理員資料取得成功");
            resp.put("response", query);
            jsr.response(resp, response);
        }
    }

    /**
     * 處理Http Method請求DELETE方法（管理員刪除會員及管理員）
     *
     * @param request Servlet請求之HttpServletRequest之Request物件（前端到後端）
     * @param response Servlet回傳之HttpServletResponse之Response物件（後端到前端）
     * @throws ServletException the servlet exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       /* JsonReader jsr = new JsonReader(request);
        JSONObject jso = jsr.getObject();

        int id = jso.getInt("id");
        String entityType = jso.getString("entityType");

        JSONObject resp = new JSONObject();

        if ("member".equals(entityType)) {
            JSONObject query = ah.deleteMemberByID(id);
            resp.put("status", "200");
            resp.put("message", "會員移除成功！");
            resp.put("response", query);
        } else if ("admin".equals(entityType)) {
            JSONObject query = ah.deleteAdminByID(id);
            resp.put("status", "200");
            resp.put("message", "管理員移除成功！");
            resp.put("response", query);
        } else {
            resp.put("status", "400");
            resp.put("message", "錯誤");
            resp.put("response", "");
        }

        jsr.response(resp, response);
        */
    	JsonReader jsr = new JsonReader(request);
        JSONObject jso = jsr.getObject();

	    String operation = jso.getString("operation");

        JSONObject resp = new JSONObject();
        int id = jso.getInt("id");
        
        /** 透過MemberHelper物件的deleteByID()方法至資料庫刪除該名會員，回傳之資料為JSONObject物件 */

        if ("member".equals(operation)) {
            JSONObject query = ah.deleteMemberByID(id);
            resp.put("status", "200");
            resp.put("message", "會員移除成功！");
            resp.put("response", query);
        } else if ("admin".equals(operation)) {
            JSONObject query = ah.deleteAdminByID(id);
            resp.put("status", "200");
            resp.put("message", "管理員移除成功！");
            resp.put("response", query);
        } else {
            resp.put("status", "400");
            resp.put("message", "錯誤");
            resp.put("response", "");
        }
        
        /** 新建一個JSONObject用於將回傳之資料進行封裝 */

        /** 透過JsonReader物件回傳到前端（以JSONObject方式） */
        jsr.response(resp, response);
    }
    

    /**
     * 處理Http Method請求PUT方法（更新）
     *
     * @param request Servlet請求之HttpServletRequest之Request物件（前端到後端）
     * @param response Servlet回傳之HttpServletResponse之Response物件（後端到前端）
     * @throws ServletException the servlet exception
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JsonReader jsr = new JsonReader(request);
        JSONObject jso = jsr.getObject();

        int id = jso.getInt("id");
        String password = jso.getString("password");
        String name = jso.getString("name");
        String entityType = jso.getString("entityType"); 

        JSONObject resp = new JSONObject();

        if ("member".equals(entityType)) {
            Member m = new Member(id, password, name);
            JSONObject data = m.update();
            resp.put("status", "200");
            resp.put("message", "成功! 更新會員資料...");
            resp.put("response", data);
        } else if ("admin".equals(entityType)) {
            Admin a = new Admin(id, password, name);
            JSONObject data = a.update();
            resp.put("status", "200");
            resp.put("message", "成功! 更新管理員資料...");
            resp.put("response", data);
        } else {
            resp.put("status", "400");
            resp.put("message", "錯誤");
            resp.put("response", "");
        }

        jsr.response(resp, response);
    }

    
    
    
}