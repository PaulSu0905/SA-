package ncu.im3069.demo.controller;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;
import org.json.*;

import ncu.im3069.demo.app.PrivateHelper;
import ncu.im3069.demo.app.PrivatePost;
import ncu.im3069.tools.JsonReader;

import javax.servlet.annotation.WebServlet;

@WebServlet("/api/privatepost.do")
public class PrivatePostController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private PrivateHelper prh = PrivateHelper.getHelper();

    public PrivatePostController() {
        super();
    }

    /**
     * 處理 Http Method 請求 GET 方法
     *
     * @param request  Servlet 請求之 HttpServletRequest 之 Request 物件（前端到後端）
     * @param response Servlet 回傳之 HttpServletResponse 之 Response 物件（後端到前端）
     * @throws ServletException Servlet例外
     * @throws IOException      IO例外
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JsonReader jsr = new JsonReader(request);
        String private_id = jsr.getParameter("private_id");
        String member_id = jsr.getParameter("member_id");
        JSONObject resp = new JSONObject();

        if (!private_id.isEmpty()) {
            JSONObject query = prh.getByID(private_id);
            resp.put("status", "200");
            resp.put("message", "私立貼文資料取得成功");
            resp.put("response", query);
        } else if(!member_id.isEmpty()){
            JSONObject query = prh.getByMember(member_id);
            resp.put("status", "200");
            resp.put("message", "該會員私立貼文資料取得成功");
            resp.put("response", query);
        }else {
            JSONObject query = prh.getAll();
            resp.put("status", "200");
            resp.put("message", "所有私立貼文資料取得成功");
            resp.put("response", query);
        }
        

        jsr.response(resp, response);
    }

    /**
     * 處理 Http Method 請求 POST 方法
     *
     * @param request  Servlet 請求之 HttpServletRequest 之 Request 物件（前端到後端）
     * @param response Servlet 回傳之 HttpServletResponse 之 Response 物件（後端到前端）
     * @throws ServletException Servlet例外
     * @throws IOException      IO例外
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JsonReader jsr = new JsonReader(request);
        JSONObject jso = jsr.getObject();
        String operation = jso.getString("operation");

        if ("submitPrivateDoPost".equals(operation)) {
            int member_id = jso.getInt("member_id");
            String member_name = jso.getString("member_name");
            String dog_name = jso.getString("dog_name");
            String dog_type = jso.getString("dog_type");
            String dog_gender = jso.getString("dog_gender");
            String dog_size = jso.getString("dog_size");
            String dog_appearance = jso.getString("dog_appearance");
            String dog_age = jso.getString("dog_age");
            String dog_ligation = jso.getString("dog_ligation");
            String dog_area = jso.getString("dog_area");
            String description = jso.getString("description");
            String status = jso.getString("status");
            String image = jso.getString("image");
            String contact_name = jso.getString("contact_name");
            String contact_phone = jso.getString("contact_phone");

            PrivatePost privatePost = new PrivatePost(0, member_id, member_name, dog_name, dog_type, dog_gender, dog_size,
                    dog_appearance, dog_age, dog_ligation, dog_area, description, image, contact_name, contact_phone, status);

            boolean isPrivateRecordExists = prh.isPrivateRecordExists(privatePost);
            if (isPrivateRecordExists) {
                JSONObject resp = new JSONObject();
                resp.put("status", "400");
                resp.put("message", "相似的私立貼文已存在");
                jsr.response(resp, response);
                return;
            }

            JSONObject result = prh.create(privatePost);

            JSONObject resp = new JSONObject();
            resp.put("status", "200");
            resp.put("message", "私立貼文新增成功！");
            resp.put("data", result);

            jsr.response(resp, response);
        } else {
            String resp = "{\"status\": '400', \"message\": '未知操作', \"response\": ''}";
            jsr.response(resp, response);
        }
    }
    /**
     * 處理 Http Method 請求 DELETE 方法
     *
     * @param request  Servlet 請求之 HttpServletRequest 之 Request 物件（前端到後端）
     * @param response Servlet 回傳之 HttpServletResponse 之 Response 物件（後端到前端）
     * @throws ServletException Servlet例外
     * @throws IOException      IO例外
     */
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JsonReader jsr = new JsonReader(request);
        JSONObject jso = jsr.getObject();

        int private_id = jso.getInt("private_id");

        JSONObject resp = new JSONObject();

        // 假設 "PrivateHelper" 是用於處理私立貼文的幫助類別
        JSONObject deletionResult = prh.deleteByID(private_id);

        // 檢查貼文是否成功刪除，假設返回的 JSON 中包含 "deleted" 欄位，並判斷其值為 true
        if (deletionResult.has("deleted") && deletionResult.getBoolean("deleted")) {
            resp.put("status", "200");
            resp.put("message", "私立貼文移除成功！");
            resp.put("response", deletionResult);
        } else {
            resp.put("status", "400");
            resp.put("message", "私立貼文移除失敗！");
            resp.put("response", deletionResult);
        }

        jsr.response(resp, response);
    }

    /**
    * 處理 Http Method 請求 PUT 方法（更新私立貼文資料）
    *
    * @param request  Servlet 請求之 HttpServletRequest 之 Request 物件（前端到後端）
     * @param response Servlet 回傳之 HttpServletResponse 之 Response 物件（後端到前端）
    * @throws ServletException Servlet例外
    * @throws IOException      IO例外
    */
    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 透過 JsonReader 類別將 Request 之 JSON 格式資料解析並取回
        JsonReader jsr = new JsonReader(request);
        JSONObject jso = jsr.getObject();

        // 從 JSON 中取出要更新的貼文編號及更新資料

        int private_id = jso.getInt("private_id");
        String status = jso.getString("status");
        

        // 建立一個新的 PrivatePost 物件，包含更新後的資料
        PrivatePost updatedPost = new PrivatePost(private_id,status);

        // 透過 PrivateHelper 物件的 update() 方法更新指定貼文編號的貼文資料
        JSONObject updateResult = prh.updateStatus(updatedPost);

        // 新建一個 JSONObject 用於將回傳之資料進行封裝
        JSONObject resp = new JSONObject();

        // 檢查貼文是否成功更新，假設返回的 JSON 中包含 "updated" 欄位，並判斷其值為 true
        if (updateResult.has("updated") && updateResult.getBoolean("updated")) {
            resp.put("status", "200");
            resp.put("message", "私立貼文更新成功！");
            resp.put("response", updateResult); // 此處可以添加其他相關的回應資訊
        } else {
            resp.put("status", "400");
            resp.put("message", "私立貼文更新失敗！");
            resp.put("response", updateResult); // 此處可以添加其他相關的回應資訊
        }

        // 透過 JsonReader 物件回傳到前端（以 JSONObject 方式）
        jsr.response(resp, response);
    }


}
