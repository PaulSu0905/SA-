package ncu.im3069.demo.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import ncu.im3069.demo.app.PrivatePost;
import ncu.im3069.demo.app.Seeking;
import ncu.im3069.demo.app.SeekingHelper;
import ncu.im3069.tools.JsonReader;

@WebServlet("/api/seekingpost.do")
public class SeekingController extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private SeekingHelper sh = SeekingHelper.getHelper();

    public SeekingController() {
        super();
    }


    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JsonReader jsr = new JsonReader(request);
        String seeking_id = jsr.getParameter("seeking_id");
        String member_id = jsr.getParameter("member_id");
        JSONObject resp = new JSONObject();

        if (!seeking_id.isEmpty()) {
            JSONObject query = sh.getByID(seeking_id);
            resp.put("status", "200");
            resp.put("message", "私立貼文資料取得成功");
            resp.put("response", query);
        } else if(!member_id.isEmpty()){
            JSONObject query = sh.getByMember(member_id);
            resp.put("status", "200");
            resp.put("message", "該會員私立貼文資料取得成功");
            resp.put("response", query);
        }else {
            JSONObject query = sh.getAll();
            resp.put("status", "200");
            resp.put("message", "所有私立貼文資料取得成功");
            resp.put("response", query);
        }
        

        jsr.response(resp, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JsonReader jsr = new JsonReader(request);
        JSONObject jso = jsr.getObject();

        String operation = jso.getString("operation");

        if ("submitSeeking".equals(operation)) {
            int member_id = jso.getInt("member_id");
            String member_name = jso.getString("member_name");
            String dog_name = jso.getString("dog_name");
            String dog_type = jso.getString("dog_type");
            String dog_gender = jso.getString("dog_gender");
            String dog_size = jso.getString("dog_size");
            String dog_time = jso.getString("dog_time");
            String dog_area = jso.getString("dog_area");
            String contact_name = jso.getString("contact_name");
            String contact_phone = jso.getString("contact_phone");
            String description = jso.getString("description");
            String status = jso.getString("status");
            String image = jso.getString("image");

            Seeking seekingPost = new Seeking(0, member_id, member_name, dog_name, dog_type, dog_gender, dog_size, dog_time,
                    dog_area, contact_name, contact_phone, description, status, image);

            boolean isSeekingRecordExists= sh.isSeekingRecordExists(seekingPost);
            if (isSeekingRecordExists) {
                JSONObject resp = new JSONObject();
                resp.put("status", "400");
                resp.put("message", "相似的協尋貼文已存在");
                jsr.response(resp, response);
                return;
            }

            JSONObject result = sh.create(seekingPost);


            JSONObject resp = new JSONObject();
            resp.put("status", "200");
            resp.put("message", "尋找貼文新增成功！");
            resp.put("data", result);

            jsr.response(resp, response);
        } else {
            String resp = "{\"status\": '400', \"message\": '未知操作', \"response\": ''}";
            jsr.response(resp, response);
        }
    }
    

    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        JsonReader jsr = new JsonReader(request);
        JSONObject jso = jsr.getObject();

        int seeking_id = jso.getInt("seeking_id");

        JSONObject resp = new JSONObject();

        JSONObject deletionResult = sh.deleteByID(seeking_id);

        if (deletionResult.has("deleted") && deletionResult.getBoolean("deleted")) {
            resp.put("status", "200");
            resp.put("message", "尋找貼文移除成功！");
            resp.put("response", deletionResult);
        } else {
            resp.put("status", "400");
            resp.put("message", "尋找貼文移除失敗！");
            resp.put("response", deletionResult);
        }

        jsr.response(resp, response);
    }

    protected void doPut(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 透過 JsonReader 類別將 Request 之 JSON 格式資料解析並取回
        JsonReader jsr = new JsonReader(request);
        JSONObject jso = jsr.getObject();

        // 從 JSON 中取出要更新的貼文編號及更新資料

        int seeking_id = jso.getInt("seeking_id");
        String status = jso.getString("status");
        

        // 建立一個新的 seekingPost 物件，包含更新後的資料
        Seeking updatedPost = new Seeking(seeking_id,status);

        // 透過 seekingHelper 物件的 update() 方法更新指定貼文編號的貼文資料
        JSONObject updateResult = sh.updateStatus(updatedPost);

        // 新建一個 JSONObject 用於將回傳之資料進行封裝
        JSONObject resp = new JSONObject();

        // 檢查貼文是否成功更新，假設返回的 JSON 中包含 "updated" 欄位，並判斷其值為 true
        if (updateResult.has("updated") && updateResult.getBoolean("updated")) {
            resp.put("status", "200");
            resp.put("message", "私立貼文更新成功！");
            resp.put("response", updateResult); // 此處可以添加其他相關的回應資訊
        } else {
            resp.put("status", "400");
            resp.put("message", "私立貼文更新失敗！");
            resp.put("response", updateResult); // 此處可以添加其他相關的回應資訊
        }

        // 透過 JsonReader 物件回傳到前端（以 JSONObject 方式）
        jsr.response(resp, response);
    }
}


