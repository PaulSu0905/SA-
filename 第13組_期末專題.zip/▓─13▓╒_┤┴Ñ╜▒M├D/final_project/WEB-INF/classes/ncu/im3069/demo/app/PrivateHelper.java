package ncu.im3069.demo.app;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.json.*;

import ncu.im3069.demo.app.Member;
import ncu.im3069.demo.app.PrivatePost;
import ncu.im3069.demo.util.DBMgr;

// TODO: Auto-generated Javadoc
/**
 * <p>
 * The Class PrivateHelper<br>
 * PrivateHelper類別（class）主要管理所有與Private相關與資料庫之方法（method）
 * </p>
 * 
 * @author IPLab
 * @version 1.0.0
 * @since 1.0.0
 */

public class PrivateHelper {
    
    /**
     * 實例化（Instantiates）一個新的（new）PrivateHelper物件<br>
     * 採用Singleton不需要透過new
     */
    private PrivateHelper() {
        
    }
    
    /** 靜態變數，儲存PrivateHelper物件 */
    private static PrivateHelper prh;
    
    /** 儲存JDBC資料庫連線 */
    private Connection conn = null;
    
    /** 儲存JDBC預準備之SQL指令 */
    private PreparedStatement pres = null;
    
    /**
     * 靜態方法<br>
     * 實作Singleton（單例模式），僅允許建立一個PrivateHelper物件
     *
     * @return the helper 回傳PrivateHelper物件
     */
    public static PrivateHelper getHelper() {
        /** Singleton檢查是否已經有PrivateHelper物件，若無則new一個，若有則直接回傳 */
        if( prh == null) prh = new PrivateHelper();
        
        return prh;
    }
    
    /**
     * 透過私立送養貼文編號（ID）刪除私立送養貼文
     *
     * @param id 私立送養貼文編號
     * @return the JSONObject 回傳SQL執行結果
     */
    public JSONObject deleteByID(int id) {
        /** 記錄實際執行之SQL指令 */
        String exexcute_sql = "";
        /** 紀錄程式開始執行時間 */
        long start_time = System.nanoTime();
        /** 紀錄SQL總行數 */
        int row = 0;
        boolean isDeleted = false;
        /** 儲存JDBC檢索資料庫後回傳之結果，以 pointer 方式移動到下一筆資料 */
        ResultSet rs = null;
        
        try {
            /** 取得資料庫之連線 */
            conn = DBMgr.getConnection();
            
            /** SQL指令 */
            String sql = "DELETE FROM `db_sa`.`tb_private` WHERE `private_id` = ? LIMIT 1";
            
            /** 將參數回填至SQL指令當中 */
            pres = conn.prepareStatement(sql);
            pres.setInt(1, id);
            /** 執行刪除之SQL指令並記錄影響之行數 */
            row = pres.executeUpdate();
            isDeleted=true;
            /** 紀錄真實執行的SQL指令，並印出 **/
            exexcute_sql = pres.toString();
            System.out.println(exexcute_sql);
            
        } catch (SQLException e) {
            /** 印出JDBC SQL指令錯誤 **/
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            /** 若錯誤則印出錯誤訊息 */
            e.printStackTrace();
        } finally {
            /** 關閉連線並釋放所有資料庫相關之資源 **/
            DBMgr.close(rs, pres, conn);
        }

        /** 紀錄程式結束執行時間 */
        long end_time = System.nanoTime();
        /** 紀錄程式執行時間 */
        long duration = (end_time - start_time);
        
        /** 將SQL指令、花費時間與影響行數，封裝成JSONObject回傳 */
        JSONObject response = new JSONObject();
        response.put("sql", exexcute_sql);
        response.put("row", row);
        response.put("time", duration);
        response.put("deleted", isDeleted);

        return response;
    }
    
    /**
     * 取回所有私立送養貼文資料
     *
     * @return the JSONObject 回傳SQL執行結果與自資料庫取回之所有資料
     */
    public JSONObject getAll() {
        /** 新建一個 Private 物件之 pv 變數，用於紀錄每一位查詢回之私立送養貼文資料 */
        PrivatePost pv = null;
        /** 用於儲存所有檢索回之公立送養貼文，以JSONArray方式儲存 */
        JSONArray jsa = new JSONArray();
        /** 記錄實際執行之SQL指令 */
        String exexcute_sql = "";
        /** 紀錄程式開始執行時間 */
        long start_time = System.nanoTime();
        /** 紀錄SQL總行數 */
        int row = 0;
        /** 儲存JDBC檢索資料庫後回傳之結果，以 pointer 方式移動到下一筆資料 */
        ResultSet rs = null;
        
        try {
            /** 取得資料庫之連線 */
            conn = DBMgr.getConnection();
            /** SQL指令 */
            String sql = "SELECT * FROM `db_sa`.`tb_private`";
            
            /** 將參數回填至SQL指令當中，若無則不用只需要執行 prepareStatement */
            pres = conn.prepareStatement(sql);
            /** 執行查詢之SQL指令並記錄其回傳之資料 */
            rs = pres.executeQuery();

            /** 紀錄真實執行的SQL指令，並印出 **/
            exexcute_sql = pres.toString();
            System.out.println(exexcute_sql);
            
            /** 透過 while 迴圈移動pointer，取得每一筆回傳資料 */
            while(rs.next()) {
                /** 每執行一次迴圈表示有一筆資料 */
                row += 1;
                /** 將 ResultSet 之資料取出 */
                int private_id = rs.getInt("private_id");
                int member_id=rs.getInt("member_id");
                String member_name=rs.getString("member_name");
                String dog_name = rs.getString("dog_name");
                String dog_type = rs.getString("dog_type");
                String dog_gender = rs.getString("dog_gender");
                String image = rs.getString("image");
                String dog_size=rs.getString("dog_size");
                String dog_appearance = rs.getString("dog_appearance");
                String contact_name = rs.getString("contact_name");
                String dog_age = rs.getString("dog_age");
                String dog_ligation = rs.getString("dog_ligation");
                String dog_area  = rs.getString("dog_area");
                String contact_phone = rs.getString("contact_phone");
                String description = rs.getString("description");
                String status = rs.getString("status");
                
                
                
                
                /** 將每一筆私立送養貼文資料產生一名新Private物件 */
                pv = new PrivatePost(private_id,member_id,member_name, dog_name, dog_type, dog_gender,dog_size,dog_appearance,dog_age,dog_ligation,dog_area,description,image,contact_name,contact_phone,status);
                /** 取出該名私立送養貼文之資料並封裝至 JSONsonArray 內 */
                jsa.put(pv.getPrivateData());
            }

        } catch (SQLException e) {
            /** 印出JDBC SQL指令錯誤 **/
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) { 
            /** 若錯誤則印出錯誤訊息 */
            e.printStackTrace();
        } finally {
            /** 關閉連線並釋放所有資料庫相關之資源 **/
            DBMgr.close(rs, pres, conn);
        }
        
        /** 紀錄程式結束執行時間 */
        long end_time = System.nanoTime();
        /** 紀錄程式執行時間 */
        long duration = (end_time - start_time);
        
        /** 將SQL指令、花費時間、影響行數與所有公立送養貼文資料之JSONArray，封裝成JSONObject回傳 */
        JSONObject response = new JSONObject();
        response.put("sql", exexcute_sql);
        response.put("row", row);
        response.put("time", duration);
        response.put("data", jsa);

        return response;
    }
    
    /**
     * 透過私立送養貼文編號（ID）取得私立送養貼文資料
     * 詳情貼文資訊
     * @param id 私立送養貼文編號
     * @return the JSON object 回傳SQL執行結果與該公立送養貼文編號之公立送養貼文資料
     */
    public JSONObject getByID(String private_id) {
        /** 新建一個 Public 物件之 pv 變數，用於紀錄每一位查詢回之公立送養貼文資料 */
        PrivatePost pv = null;
        /** 用於儲存所有檢索回之公立送養貼文，以JSONArray方式儲存 */
        JSONArray jsa = new JSONArray();
        /** 記錄實際執行之SQL指令 */
        String exexcute_sql = "";
        /** 紀錄程式開始執行時間 */
        long start_time = System.nanoTime();
        /** 紀錄SQL總行數 */
        int row = 0;
        /** 儲存JDBC檢索資料庫後回傳之結果，以 pointer 方式移動到下一筆資料 */
        ResultSet rs = null;
        
        try {
            /** 取得資料庫之連線 */
            conn = DBMgr.getConnection();
            /** SQL指令 */
            String sql = "SELECT * FROM `db_sa`.`tb_private` WHERE `private_id` = ? LIMIT 1";
            
            /** 將參數回填至SQL指令當中 */
            pres = conn.prepareStatement(sql);
            pres.setString(1, private_id);
            /** 執行查詢之SQL指令並記錄其回傳之資料 */
            rs = pres.executeQuery();

            /** 紀錄真實執行的SQL指令，並印出 **/
            exexcute_sql = pres.toString();
            System.out.println(exexcute_sql);
            
            if (rs.next()) {
                /** 將 ResultSet 之資料取出 */
                String name = rs.getString("dog_name");
                String type = rs.getString("dog_type");
                String gender = rs.getString("dog_gender");
                String size = rs.getString("dog_size");
                String appearance = rs.getString("dog_appearance");
                String age = rs.getString("dog_age");
                String ligation = rs.getString("dog_ligation");
                String area = rs.getString("dog_area");
                String description = rs.getString("description");
                String  image = rs.getString("image");
                String contact_name = rs.getString("contact_name");
                String contact_phone = rs.getString("contact_phone");

                /** 將該筆私立送養貼文資料產生一名新 Private 物件 */
                pv = new PrivatePost(name, type, gender, size, appearance, age, ligation, area, description, image, contact_name, contact_phone);
                /** 將該私立送養貼文之資料封裝至 JSONArray 內 */
                jsa.put(pv.getPrivateData());
            }
            
            
        } catch (SQLException e) {
            /** 印出JDBC SQL指令錯誤 **/
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            /** 若錯誤則印出錯誤訊息 */
            e.printStackTrace();
        } finally {
            /** 關閉連線並釋放所有資料庫相關之資源 **/
            DBMgr.close(rs, pres, conn);
        }
        
        /** 紀錄程式結束執行時間 */
        long end_time = System.nanoTime();
        /** 紀錄程式執行時間 */
        long duration = (end_time - start_time);
        
        /** 將SQL指令、花費時間、影響行數與所有公立送養貼文資料之JSONArray，封裝成JSONObject回傳 */
        JSONObject response = new JSONObject();
        response.put("sql", exexcute_sql);
        response.put("row", row);
        response.put("time", duration);
        response.put("data", jsa);

        return response;
    }
    
    /**
     * 透過會員編號（ID）取得私立送養貼文資料
     *
     * @param member_id 會員編號
     * @return the JSON object 回傳SQL執行結果與該私立送養貼文編號之貼文資料
     */
    public JSONObject getByMember(String member_id) {
        /** 新建一個 private 物件之 pv 變數，用於紀錄每一位會員查詢回之刊登私立送養貼文資料 */
        PrivatePost pv = null;
        /** 用於儲存所有檢索回之協尋貼文，以JSONArray方式儲存 */
        JSONArray jsa = new JSONArray();
        /** 記錄實際執行之SQL指令 */
        String exexcute_sql = "";
        /** 紀錄程式開始執行時間 */
        long start_time = System.nanoTime();
        /** 紀錄SQL總行數 */
        int row = 0;
        /** 儲存JDBC檢索資料庫後回傳之結果，以 pointer 方式移動到下一筆資料 */
        ResultSet rs = null;
        
        try {
            /** 取得資料庫之連線 */
            conn = DBMgr.getConnection();
            /** SQL指令 */
            String sql = "SELECT * FROM `db_sa`.`tb_private` WHERE member_id = ?";
            
            /** 將參數回填至SQL指令當中 */
            pres = conn.prepareStatement(sql);

            pres.setInt(1, Integer.parseInt(member_id));
            /** 執行查詢之SQL指令並記錄其回傳之資料 */
            rs = pres.executeQuery();

            /** 紀錄真實執行的SQL指令，並印出 **/
            exexcute_sql = pres.toString();
            System.out.println(exexcute_sql);
            
            while (rs.next()) {
             row++;
                /** 將 ResultSet 之資料取出 */
             int m_id = rs.getInt("member_id");
             int p_id = rs.getInt("private_id");
                String name = rs.getString("dog_name");
                String type = rs.getString("dog_type");
                String gender = rs.getString("dog_gender");
                String size = rs.getString("dog_size");
                String appearance = rs.getString("dog_appearance");
                String age = rs.getString("dog_age");
                String ligation = rs.getString("dog_ligation");
                String area = rs.getString("dog_area");
                String description = rs.getString("description");
                String image = rs.getString("image");
                String contact_name = rs.getString("contact_name");
                String contact_phone = rs.getString("contact_phone");
                String status = rs.getString("status");

                /** 將該筆協尋貼文資料產生一名新 Seeking 物件 */
                pv = new PrivatePost(p_id, m_id, name, type, gender, size, appearance, age, ligation, area, description, image, contact_name, contact_phone, status);
                /** 將該協尋貼文之資料封裝至 JSONArray 內 */
                jsa.put(pv.getPrivateData());
            }
            
            
        } catch (SQLException e) {
            /** 印出JDBC SQL指令錯誤 **/
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            /** 若錯誤則印出錯誤訊息 */
            e.printStackTrace();
        } finally {
            /** 關閉連線並釋放所有資料庫相關之資源 **/
            DBMgr.close(rs, pres, conn);
        }
        
        /** 紀錄程式結束執行時間 */
        long end_time = System.nanoTime();
        /** 紀錄程式執行時間 */
        long duration = (end_time - start_time);
        
        /** 將SQL指令、花費時間、影響行數與所有協尋貼文資料之JSONArray，封裝成JSONObject回傳 */
        JSONObject response = new JSONObject();
        response.put("sql", exexcute_sql);
        response.put("row", row);
        response.put("time", duration);
        response.put("data", jsa);

        return response;
    }
    
    
    /**
     * 建立該私立送養貼文至資料庫
     *
     * @param pv 一名私立送養貼文之Private物件
     * @return the JSON object 回傳SQL指令執行之結果
     */
    
    /**
     * 建立該私立送養貼文至資料庫
     *
     * @param pv 一名私立送養貼文之Private物件
     * @return the JSON object 回傳SQL指令執行之結果
     */
    public JSONObject create(PrivatePost privatePost) {
        /** Record the actual executed SQL command */
        String executeSql = "";
        /** Record the program's start execution time */
        long startTime = System.nanoTime();
        /** Record the total number of SQL rows */
        int row = 0;

        try {
            /** Get the database connection */
            conn = DBMgr.getConnection();
            /** SQL command */
            String sql = "INSERT INTO `db_sa`.`tb_private`(`member_id`, `member_name`, `dog_name`, `dog_type`, `dog_gender`, `dog_size`, `dog_appearance`, `dog_age`, `dog_ligation`, `dog_area`, `contact_name`, `contact_phone`, `description`, `status`, `image`)"
                    + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            /** Get the required parameters */
            int memberId = privatePost.getMemberID();
            String memberName = privatePost.getMemberName();
            String dogName = privatePost.getDogName();
            String dogType = privatePost.getDogType();
            String dogGender = privatePost.getDogGender();
            String dogSize = privatePost.getDogSize();
            String dogAppearance = privatePost.getDogAppearance();
            String dogAge = privatePost.getDogAge();
            String dogLigation = privatePost.getDogLigation();
            String dogArea = privatePost.getDogArea();
            String description = privatePost.getDescription();
            String image = privatePost.getImage();
            String contactName = privatePost.getContactName();
            String contactPhone = privatePost.getContactPhone();
            String status = privatePost.getStatus();

            /** Set the parameters to the SQL command */
            pres = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            pres.setInt(1, memberId);
            pres.setString(2, memberName);
            pres.setString(3, dogName);
            pres.setString(4, dogType);
            pres.setString(5, dogGender);
            pres.setString(6, dogSize);
            pres.setString(7, dogAppearance);
            pres.setString(8, dogAge);
            pres.setString(9, dogLigation);
            pres.setString(10, dogArea);
            pres.setString(11, contactName);
            pres.setString(12, contactPhone);
            pres.setString(13, description);
            pres.setString(14, status);
            pres.setString(15, image);

            /** Execute the SQL command for insertion and record the number of affected rows */
            row = pres.executeUpdate();
            

            ResultSet generatedKeys = pres.getGeneratedKeys();
            if (generatedKeys.next()) {
                privatePost.setId(generatedKeys.getInt(1));
            }
            /** Record the actual executed SQL command and print it **/
            executeSql = pres.toString();
            System.out.println(executeSql);

        } catch (SQLException e) {
            /** Print JDBC SQL command error **/
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            /** If an error occurs, print the error message */
            e.printStackTrace();
        } finally {
            /** Close the connection and release all related database resources **/
            DBMgr.close(pres, conn);
        }

        /** Record the program's end execution time */
        long endTime = System.nanoTime();
        /** Record the program's execution time */
        long duration = (endTime - startTime);

        /** Package the SQL command, execution time, and affected rows into a JSONObject and return it */
        JSONObject response = new JSONObject();
        response.put("sql", executeSql);
        response.put("time", duration);
        response.put("row", row);

        return response;
    }
    
    /** 條件搜尋*/
    public JSONObject getByConditions(String Type, String Area) {
      /** 新建一個 Private 物件之 pv 變數，用於紀錄每一篇查詢回之私立送養貼文 */
      PrivatePost pv = null;
      /** 用於儲存所有檢索回之公立送養貼文，以JSONArray方式儲存 */    /** ?  */
      JSONArray jsa = new JSONArray();
      /** 記錄實際執行之SQL指令 */
      String exexcute_sql = "";
      /** 紀錄程式開始執行時間 */
      long start_time = System.nanoTime();
      /** 紀錄SQL總行數 */
      int row = 0;
      /** 儲存JDBC檢索資料庫後回傳之結果，以 pointer 方式移動到下一筆資料 */
      ResultSet rs = null;

      try {
          /** 取得資料庫之連線 */
          conn = DBMgr.getConnection();
          StringBuilder sqlBuilder = new StringBuilder("SELECT * FROM `db_sa`.`tb_private` WHERE 1=1");
          /** SQL指令 */
          List<String> conditions = new ArrayList<>();
        if (Type != null && !Type.isEmpty()) {
            conditions.add("`private_type` = ?");
        }
        if (Area != null && !Area.isEmpty()) {
            conditions.add("`private_area` = ?");
        }

        if (!conditions.isEmpty()) {
            sqlBuilder.append(" AND (").append(String.join(" OR ", conditions)).append(")");
        }

        pres = conn.prepareStatement(sqlBuilder.toString());

        // 填入條件值
        int parameterIndex = 1;
        if (Type != null && !Type.isEmpty()) {
            pres.setString(parameterIndex++, Type);
        }
        if (Area != null && !Area.isEmpty()) {
            pres.setString(parameterIndex++, Area);
        }

          /** 執行查詢之SQL指令並記錄其回傳之資料 */
          rs = pres.executeQuery();

          /** 紀錄真實執行的SQL指令，並印出 **/
          exexcute_sql = pres.toString();
          System.out.println(exexcute_sql);
          
          /** 透過 while 迴圈移動pointer，取得每一筆回傳資料 */
          while(rs.next()) {
              /** 每執行一次迴圈表示有一筆資料 */
              row += 1;
              
              /** 將 ResultSet 之資料取出 */
                String name = rs.getString("dog_name");
                String type = rs.getString("dog_type");
                String gender = rs.getString("dog_gender");
                String size = rs.getString("dog_size");
                String appearance = rs.getString("dog_appearance");
                String age = rs.getString("dog_age");
                String ligation = rs.getString("dog_ligation");
                String area = rs.getString("dog_area");
                String description = rs.getString("description");
                String image = rs.getString("image");
                String contact_name = rs.getString("contact_name");
                String contact_phone = rs.getString("contact_phone");
                
              /** 將每一筆貼文資料產生一名新Private物件 */
              pv = new PrivatePost(name, type, gender, size, appearance, age, ligation, area, description, image, contact_name, contact_phone);
              /** 取出該項貼文之資料並封裝至 JSONsonArray 內 */
              jsa.put(pv.getData());
          }

      } catch (SQLException e) {
          /** 印出JDBC SQL指令錯誤 **/
          System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
      } catch (Exception e) {
          /** 若錯誤則印出錯誤訊息 */
          e.printStackTrace();
      } finally {
          /** 關閉連線並釋放所有資料庫相關之資源 **/
          DBMgr.close(rs, pres, conn);
      }
      
      /** 紀錄程式結束執行時間 */
      long end_time = System.nanoTime();
      /** 紀錄程式執行時間 */
      long duration = (end_time - start_time);
      
      /** 將SQL指令、花費時間、影響行數與所有公立送養貼文資料之JSONArray，封裝成JSONObject回傳 */
      JSONObject response = new JSONObject();
      response.put("sql", exexcute_sql);
      response.put("row", row);
      response.put("time", duration);
      response.put("data", jsa);

      return response;
    }
    
    /**
     * 更新一篇私立送養貼文資料
     *
     * @param pv 一篇私立送養貼文物件
     * @return the JSONObject 回傳SQL指令執行結果與執行之資料
     */
    
   
     public JSONObject update(PrivatePost pv) {
        JSONArray jsa = new JSONArray();
        String exexcute_sql = "";
        long start_time = System.nanoTime();
        int row = 0;

        try {
            conn = DBMgr.getConnection();
            StringBuilder sqlBuilder = new StringBuilder("UPDATE `db_sa`.`tb_private` SET ");
            ArrayList<String> updateColumns = new ArrayList<>();
            ArrayList<Object> values = new ArrayList<>(); // To store corresponding values

            if (pv.getDogName() != null && !pv.getDogName().isEmpty()) {
                updateColumns.add("`dog_name` = ?");
                values.add(pv.getDogName());
            }
            if (pv.getDogType() != null && !pv.getDogType().isEmpty()) {
                updateColumns.add("`dog_type` = ?");
                values.add(pv.getDogType());
            }
            if (pv.getDogGender() != null && !pv.getDogGender().isEmpty()) {
                updateColumns.add("`dog_gender` = ?");
                values.add(pv.getDogGender());
            }
            if (pv.getDogSize() != null && !pv.getDogSize().isEmpty()) {
                updateColumns.add("`dog_size` = ?");
                values.add(pv.getDogSize());
            }
            if (pv.getDogAppearance() != null && !pv.getDogAppearance().isEmpty()) {
                updateColumns.add("`dog_appearance` = ?");
                values.add(pv.getDogAppearance());
            }
            if (pv.getDogAge() != null && !pv.getDogAge().isEmpty()) {
                updateColumns.add("`dog_age` = ?");
                values.add(pv.getDogAge());
            }
            if (pv.getDogLigation() != null && !pv.getDogLigation().isEmpty()) {
                updateColumns.add("`dog_ligation` = ?");
                values.add(pv.getDogLigation());
            }
            if (pv.getDogArea() != null && !pv.getDogArea().isEmpty()) {
                updateColumns.add("`dog_area` = ?");
                values.add(pv.getDogArea());
            }
            if (pv.getDescription() != null && !pv.getDescription().isEmpty()) {
                updateColumns.add("`description` = ?");
                values.add(pv.getDescription());
            }
            if (pv.getImage() != null && !pv.getImage().isEmpty()) {
                updateColumns.add("`lmage` = ?");
                values.add(pv.getImage());
            }
            if (pv.getContactName() != null && !pv.getContactName().isEmpty()) {
                updateColumns.add("`contact_name` = ?");
                values.add(pv.getContactName());
            }
            if (pv.getContactPhone() != null && !pv.getContactPhone().isEmpty()) {
                updateColumns.add("`contact_phone` = ?");
                values.add(pv.getContactPhone());
            }
            // Add other columns to update...

            if (!updateColumns.isEmpty()) {
                sqlBuilder.append(String.join(", ", updateColumns));
                sqlBuilder.append(" WHERE `private_id` = ?");

                pres = conn.prepareStatement(sqlBuilder.toString());

                int parameterIndex = 1;

                for (Object value : values) {
                    if (value instanceof String) {
                        pres.setString(parameterIndex++, (String) value);
                    } else if (value instanceof Integer) {
                        pres.setInt(parameterIndex++, (Integer) value);
                    }
                }

                // Set ID for the WHERE clause
                pres.setInt(parameterIndex, pv.getID());

                row = pres.executeUpdate();

                exexcute_sql = pres.toString();
                System.out.println(exexcute_sql);
            }
            
        
        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBMgr.close(pres, conn);
        }

        long end_time = System.nanoTime();
        long duration = (end_time - start_time);

        JSONObject response = new JSONObject();
        response.put("sql", exexcute_sql);
        response.put("row", row);
        response.put("time", duration);
        response.put("data", jsa);

        return response;
    }
    
     
     
     public JSONObject updateStatus(PrivatePost pv) {
         /** 紀錄回傳之資料 */
         JSONArray jsa = new JSONArray();
         /** 記錄實際執行之SQL指令 */
         String exexcute_sql = "";
         /** 紀錄程式開始執行時間 */
         long start_time = System.nanoTime();
         /** 紀錄SQL總行數 */
         int row = 0;
         
         try {
             /** 取得資料庫之連線 */
             conn = DBMgr.getConnection();
             /** SQL指令 */
             String sql = "Update `db_sa`.`tb_private` SET `status` = ?  WHERE `private_id` = ?";
             /** 取得所需之參數 */
             int id = pv.getID();
             String status = pv.getStatus();
             
             /** 將參數回填至SQL指令當中 */
             pres = conn.prepareStatement(sql);
             pres.setString(1, status);
             pres.setInt(2, id);
             /** 執行更新之SQL指令並記錄影響之行數 */
             row = pres.executeUpdate();

             /** 紀錄真實執行的SQL指令，並印出 **/
             exexcute_sql = pres.toString();
             System.out.println(exexcute_sql);

         } catch (SQLException e) {
             /** 印出JDBC SQL指令錯誤 **/
             System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
         } catch (Exception e) {
             /** 若錯誤則印出錯誤訊息 */
             e.printStackTrace();
         } finally {
             /** 關閉連線並釋放所有資料庫相關之資源 **/
             DBMgr.close(pres, conn);
         }
         
         /** 紀錄程式結束執行時間 */
         long end_time = System.nanoTime();
         /** 紀錄程式執行時間 */
         long duration = (end_time - start_time);
         
         /** 將SQL指令、花費時間與影響行數，封裝成JSONObject回傳 */
         JSONObject response = new JSONObject();
         response.put("sql", exexcute_sql);
         response.put("row", row);
         response.put("time", duration);
         response.put("data", jsa);

         return response;
     }
     
     public boolean isPrivateRecordExists(PrivatePost privatePost) {
         int row = 0;
         ResultSet rs = null;

         try {
             conn = DBMgr.getConnection();
             String sql = "SELECT COUNT(*) AS row FROM `db_sa`.`tb_private` WHERE " +
                     "`dog_name` = ? AND " +
                     "`dog_type` = ? AND " +
                     "`dog_gender` = ? AND " +
                     "`dog_size` = ? AND " +
                     "`dog_appearance` = ? AND " +
                     "`dog_age` = ? AND " +
                     "`dog_ligation` = ? AND " +
                     "`dog_area` = ?";
             
             pres = conn.prepareStatement(sql);
             pres.setString(1, privatePost.getDogName());
             pres.setString(2, privatePost.getDogType());
             pres.setString(3, privatePost.getDogGender());
             pres.setString(4, privatePost.getDogSize());
             pres.setString(5, privatePost.getDogAppearance());
             pres.setString(6, privatePost.getDogAge());
             pres.setString(7, privatePost.getDogLigation());
             pres.setString(8, privatePost.getDogArea());

             rs = pres.executeQuery();
             
             rs.next();
             row = rs.getInt("row");

         } catch (SQLException e) {
             System.err.format("SQL State: %s\n%s\n%s", e.getErrorCode(), e.getSQLState(), e.getMessage());
         } catch (Exception e) {
             e.printStackTrace();
         } finally {
             DBMgr.close(rs, pres, conn);
         }

         return (row > 0);
     }
}
            
 
