package ncu.im3069.demo.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import ncu.im3069.demo.app.Member;
import ncu.im3069.demo.app.MemberHelper;
import ncu.im3069.tools.JsonReader;

/**
 * Servlet implementation class MemberController
 */
@WebServlet("/api/member.do")
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MemberHelper mh = MemberHelper.getHelper();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MemberController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		JsonReader jsr = new JsonReader(request);
        String id = jsr.getParameter("member_id");

        if (id == null || id.isEmpty()) {
            JSONObject query = mh.getAll();
            JSONObject resp = new JSONObject();
            resp.put("status", "200");
            resp.put("message", "所有會員資料取得成功");
            resp.put("response", query);
            jsr.response(resp, response);
        } else {
            JSONObject query = mh.getByID(id);
            JSONObject resp = new JSONObject();
            resp.put("status", "200");
            resp.put("message", "會員資料取得成功");
            resp.put("response", query);
            jsr.response(resp, response);
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		JsonReader jsr = new JsonReader(request);
//        JSONObject jso = jsr.getObject();
//
//        String ic = jso.getString("member_icno");
//        String phone = jso.getString("member_phone");
//        String password = jso.getString("member_password");
//        String name = jso.getString("member_name");
//
//        // Fix: Corrected the parameter to instantiate Member object
//        Member m = new Member(name, ic, phone, password);
//
//        if (name.isEmpty() || ic.isEmpty() || phone.isEmpty() || password.isEmpty()) {
//            String resp = "{\"status\": '400', \"message\": '欄位不能有空值', \"response\": ''}";
//            jsr.response(resp, response);
//        } else {}
//            boolean isDuplicateIC = mh.checkDuplicateIC(m);
//            boolean isDuplicatePhone = mh.checkDuplicatePhone(m);
//
//            if (!isDuplicateIC && !isDuplicatePhone) {
//                JSONObject data = mh.create(m);
//                JSONObject resp = new JSONObject();
//                resp.put("status", "200");
//                resp.put("message", "成功! 註冊會員資料...");
//                resp.put("response", data);
//
//                jsr.response(resp, response);
//            } else {
//                String resp;
//                if (isDuplicateIC && isDuplicatePhone) {
//                    resp = "{\"status\": '400', \"message\": '新增帳號失敗，此身分證字號和電話號碼已存在！', \"response\": ''}";
//                } else if (isDuplicateIC) {
//                    resp = "{\"status\": '400', \"message\": '新增帳號失敗，此身分證字號已存在！', \"response\": ''}";
//                } else {
//                    resp = "{\"status\": '400', \"message\": '新增帳號失敗，此電話號碼已存在！', \"response\": ''}";
//                }
//                jsr.response(resp, response);
//            }
//	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    JsonReader jsr = new JsonReader(request);
	    JSONObject jso = jsr.getObject();

	    String operation = jso.getString("operation");

	    if ("login".equals(operation)) {
	    	String phone = jso.getString("phone");
		    String password = jso.getString("password");

		    if (phone == null || password == null || phone.isEmpty() || password.isEmpty()) {
		        JSONObject resp = new JSONObject();
		        resp.put("status", "400");
		        resp.put("message", "用戶名或密碼不能為空");
		        jsr.response(resp, response);
		        return;
		    }

		    Member user = mh.getMemberByPhone(phone);

		    if (user == null) {
		        JSONObject resp = new JSONObject();
		        resp.put("status", "401");
		        resp.put("message", "用户不存在");
		        jsr.response(resp, response);
		        return;
		    }

		    if (!user.getPassword().equals(password)) {
		        JSONObject resp = new JSONObject();
		        resp.put("status", "401");
		        resp.put("message", "密碼錯誤");
		        jsr.response(resp, response);
		        return;
		    }

		    JSONObject resp = new JSONObject();
		    resp.put("status", "200");
		    resp.put("message", "登入成功");
		    resp.put("member_id", user.getID()); 
		    resp.put("member_name", user.getName());	    
		    jsr.response(resp, response);
	    } else if ("register".equals(operation)) {
		    String ic = jso.getString("member_icno");
		    String phone = jso.getString("member_phone");
		    String password = jso.getString("member_password");
		    String name = jso.getString("member_name");

		    Member m = new Member(name, ic, phone, password);

		    if (name.isEmpty() || ic.isEmpty() || phone.isEmpty() || password.isEmpty()) {
		        String resp = "{\"status\": '400', \"message\": '欄位不能有空值', \"response\": ''}";
		        jsr.response(resp, response);
		        return;
		    }

		    boolean isDuplicateIC = mh.checkDuplicateIC(m);
		    boolean isDuplicatePhone = mh.checkDuplicatePhone(m);

		    if (!isDuplicateIC && !isDuplicatePhone) {
		        JSONObject data = mh.create(m);
		        JSONObject resp = new JSONObject();
		        resp.put("status", "200");
		        resp.put("message", "成功! 註冊會員資料...");
		        resp.put("response", data);

		        jsr.response(resp, response);
		    } else {
		        String resp;
		        if (isDuplicateIC && isDuplicatePhone) {
		            resp = "{\"status\": '400', \"message\": '新增帳號失敗，此身分證字號和電話號碼已存在！', \"response\": ''}";
		        } else if (isDuplicateIC) {
		            resp = "{\"status\": '400', \"message\": '新增帳號失敗，此身分證字號已存在！', \"response\": ''}";
		        } else {
		            resp = "{\"status\": '400', \"message\": '新增帳號失敗，此電話號碼已存在！', \"response\": ''}";
		        }
		        jsr.response(resp, response);
		    }
	    } else {
	        String resp = "{\"status\": '400', \"message\": '未知操作', \"response\": ''}";
	        jsr.response(resp, response);
	    }
	}



	/**
	 * @see HttpServlet#doPut(HttpServletRequest, HttpServletResponse)
	 */
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/** 透過JsonReader類別將Request之JSON格式資料解析並取回 */
        JsonReader jsr = new JsonReader(request);
        JSONObject jso = jsr.getObject();

        /** 取出經解析到JSONObject之Request參數 */
        int id = jso.getInt("member_id");
        String password = jso.getString("member_password");
        String name = jso.getString("member_name");

        /** 透過傳入之參數，新建一個以這些參數之會員Member物件 */
        Member m = new Member(id, name, password);

        /** 透過Member物件的update()方法至資料庫更新該名會員資料，回傳之資料為JSONObject物件 */
        JSONObject data = m.update();

        /** 新建一個JSONObject用於將回傳之資料進行封裝 */
        JSONObject resp = new JSONObject();
        resp.put("status", "200");
        resp.put("message", "成功! 更新會員資料...");
        resp.put("response", data);

        /** 透過JsonReader物件回傳到前端（以JSONObject方式） */
        jsr.response(resp, response);
	}

	/**
	 * @see HttpServlet#doDelete(HttpServletRequest, HttpServletResponse)
	 */
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
