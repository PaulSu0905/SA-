package ncu.im3069.demo.app;

import org.json.*;

// TODO: Auto-generated Javadoc
/**
 * <p>
 * The Class Member
 * Member類別（class）具有會員所需要之屬性與方法，並且儲存與會員相關之商業判斷邏輯<br>
 * </p>
 * 
 * @author IPLab
 * @version 1.0.0
 * @since 1.0.0
 */

public class Member {
    
    /** id，會員編號 */
    private int id;
    
    /** name，會員姓名 */
    private String name;

    /** ic，身分證 */
    private String ic;    

    /** phone，電話 */
    private String phone;  

    /** password，會員密碼 */
    private String password;
    
    /** mh，MemberHelper之物件與Member相關之資料庫方法（Sigleton） */
    private MemberHelper mh =  MemberHelper.getHelper();
    
    /**
     * 實例化（Instantiates）一個新的（new）Member物件<br>
     * 採用多載（overload）方法進行，此建構子用於建立會員資料時，產生一名新的會員
     * 
     * @param name 會員姓名
     * @param ic 
     * @param phone
     * @param password 會員密碼
    
     */
    public Member(String name, String ic, String phone, String password ) {
        this.name = name;
        this.ic = ic;
        this.phone = phone;
        this.password = password;
        
        update();
    }

    /**
     * 實例化（Instantiates）一個新的（new）Member物件<br>
     * 採用多載（overload）方法進行，此建構子用於更新會員資料時，產生一名會員同時需要去資料庫檢索原有更新時間分鐘數與會員組別
     * 
     * @param id 會員編號
     * @param name 會員姓名
     * @param password 會員密碼
     */
    public Member(int id, String name, String password) {
        this.id = id;
        this.name = name;
        this.password = password;
        
    }
    
    /**
     * 實例化（Instantiates）一個新的（new）Member物件<br>
     * 採用多載（overload）方法進行，此建構子用於查詢會員資料時，將每一筆資料新增為一個會員物件
     *
     * @param id 會員編號
     * @param name 會員姓名
     * @param ic
     * @param phone
     * @param password 會員密碼
     */
    public Member(int id, String name, String ic, String phone, String password) {
        this.id = id;
        this.name = name;
        this.ic = ic;
        this.phone = phone;
        this.password = password;

    }
    
    /**
     * 取得會員之編號
     *
     * @return the id 回傳會員編號
     */
    public int getID() {
        return this.id;
    }

    /**
     * 取得會員之電話
     *
     * @return the phone 回傳會員電話
     */
     public String getPhone() {
        return this.phone;
    }

    /**
     * 取得會員之密碼
     *
     * @return the password 回傳會員密碼
     */
    public String getPassword() {
        return this.password;
    }

    /**
     * 取得會員之身分證
     *
     * @return the ic 回傳會員身分證
     */
    public String getIC() {
        return this.ic;
    }


    /**
     * 取得會員之姓名
     *
     * @return the name 回傳會員姓名
     */
    public String getName() {
        return this.name;
    }

    
    /**
     * 更新會員資料   (未完成)
     *
     * @return the JSON object 回傳SQL更新之結果與相關封裝之資料
     */
    public JSONObject update() {
        /** 新建一個JSONObject用以儲存更新後之資料 */
        JSONObject data = new JSONObject();
        
        /** 檢查該名會員是否已經在資料庫 */
        if(this.id != 0) {
            /** 若有則將目前更新後之資料更新至資料庫中 */
            /** 透過MemberHelper物件，更新目前之會員資料置資料庫中 */
            data = mh.update(this);
        }
        
        return data;
    }
    
    /**
     * 取得該名會員所有資料
     *
     * @return the data 取得該名會員之所有資料並封裝於JSONObject物件內
     */
    public JSONObject getData() {
        /** 透過JSONObject將該名會員所需之資料全部進行封裝*/ 
        JSONObject jso = new JSONObject();
        jso.put("member_id", getID());
        jso.put("member_name", getName()); 
        jso.put("member_icno", getIC());   
        jso.put("member_phone", getPhone());   
        jso.put("member_password", getPassword()); 
        

        return jso;
    }

    
}