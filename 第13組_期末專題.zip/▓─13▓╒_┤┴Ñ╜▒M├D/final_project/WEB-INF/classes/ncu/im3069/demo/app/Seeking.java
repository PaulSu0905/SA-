package ncu.im3069.demo.app;

import org.json.*;

public class Seeking {

    private int seeking_id;
    private int member_id;
    private String member_name;
    private String dog_name;
    private String dog_type;
    private String dog_gender;
    private String dog_size;
    private String dog_time;
    private String dog_area;
    private String contact_name;
    private String contact_phone;
    private String description;
    private String status;
    private String image;

    public Seeking(int seeking_id, int member_id, String member_name, String dog_name, String dog_type, String dog_gender,
            String dog_size, String dog_time, String dog_area, String contact_name, String contact_phone,
            String description, String status, String image) {
        this.seeking_id = seeking_id;
        this.member_id = member_id;
        this.member_name = member_name;
        this.dog_name = dog_name;
        this.dog_type = dog_type;
        this.dog_gender = dog_gender;
        this.dog_size = dog_size;
        this.dog_time = dog_time;
        this.dog_area = dog_area;
        this.contact_name = contact_name;
        this.contact_phone = contact_phone;
        this.description = description;
        this.status = status;
        this.image = image;
    }
    
    public Seeking(int seeking_id, int member_id, String dog_name, String dog_type, String dog_gender,
            String dog_size, String dog_time, String dog_area, String contact_name, String contact_phone,
            String description, String status, String image) {
        this.seeking_id = seeking_id;
        this.member_id = member_id;
        this.dog_name = dog_name;
        this.dog_type = dog_type;
        this.dog_gender = dog_gender;
        this.dog_size = dog_size;
        this.dog_time = dog_time;
        this.dog_area = dog_area;
        this.contact_name = contact_name;
        this.contact_phone = contact_phone;
        this.description = description;
        this.status = status;
        this.image = image;
    }
    
    public Seeking(String dog_name, String dog_type, String dog_gender,
            String dog_size, String dog_time, String dog_area, String contact_name, String contact_phone,
            String description, String status, String image) {
        this.dog_name = dog_name;
        this.dog_type = dog_type;
        this.dog_gender = dog_gender;
        this.dog_size = dog_size;
        this.dog_time = dog_time;
        this.dog_area = dog_area;
        this.contact_name = contact_name;
        this.contact_phone = contact_phone;
        this.description = description;
        this.status = status;
        this.image = image;
    }
  
    public Seeking(int seeking_id, String status) {
    	this.seeking_id = seeking_id;
    	this.status = status;
    }

    // Getters and Setters

    public int getSeeking_id() {
        return seeking_id;
    }

    public void setSeeking_id(int seeking_id) {
        this.seeking_id = seeking_id;
    }

    public int getMember_id() {
        return member_id;
    }

    public void setMember_id(int member_id) {
        this.member_id = member_id;
    }

    public String getMember_name() {
        return member_name;
    }

    public void setMember_name(String member_name) {
        this.member_name = member_name;
    }

    public String getDog_name() {
        return dog_name;
    }

    public void setDog_name(String dog_name) {
        this.dog_name = dog_name;
    }

    public String getDog_type() {
        return dog_type;
    }

    public void setDog_type(String dog_type) {
        this.dog_type = dog_type;
    }

    public String getDog_gender() {
        return dog_gender;
    }

    public void setDog_gender(String dog_gender) {
        this.dog_gender = dog_gender;
    }

    public String getDog_size() {
        return dog_size;
    }

    public void setDog_size(String dog_size) {
        this.dog_size = dog_size;
    }

    public String getDog_time() {
        return dog_time;
    }

    public void setDog_time(String dog_time) {
        this.dog_time = dog_time;
    }

    public String getDog_area() {
        return dog_area;
    }

    public void setDog_area(String dog_area) {
        this.dog_area = dog_area;
    }

    public String getContact_name() {
        return contact_name;
    }

    public void setContact_name(String contact_name) {
        this.contact_name = contact_name;
    }

    public String getContact_phone() {
        return contact_phone;
    }

    public void setContact_phone(String contact_phone) {
        this.contact_phone = contact_phone;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    
    public JSONObject toJSON() {
        JSONObject jsonObj = new JSONObject();
        jsonObj.put("seeking_id", this.seeking_id);
        jsonObj.put("member_id", this.member_id);
        jsonObj.put("member_name", this.member_name);
        jsonObj.put("dog_name", this.dog_name);
        jsonObj.put("dog_type", this.dog_type);
        jsonObj.put("dog_gender", this.dog_gender);
        jsonObj.put("dog_size", this.dog_size);
        jsonObj.put("dog_time", this.dog_time);
        jsonObj.put("dog_area", this.dog_area);
        jsonObj.put("contact_name", this.contact_name);
        jsonObj.put("contact_phone", this.contact_phone);
        jsonObj.put("description", this.description);
        jsonObj.put("status", this.status);
        jsonObj.put("image", this.image);

        return jsonObj;
    }
}
